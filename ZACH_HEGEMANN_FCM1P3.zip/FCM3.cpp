// FCM3.cpp, Zach Hegemann. This program covers piecewise polynomial interpolation, splines, and B-splines
//

#include <iostream>
#include <vector>
#include <random>
#include <time.h>
#include "interp.h"
#include <fstream>

// A mapping from the interval [x_i, x_{i+1}] to [0,1] or [x_i, x_{i+2}] to [-1,1]
// depending on the degree of the piecewise interpolation
// Parameters: x_i, x_j, x_k are the ordered mesh points
// double z_map(double x_i, double x_j, double x_k, Degree degree);

// A function from the lecture slides
double f1(double x);
// A function from the lecture slides
float f1(float x);



int main()
{
	srand(time(0));
	const size_t N = 1000;
	size_t n = 10;
	double left_end = -1;
	double right_end = 1;
	Mesh meshtype = Mesh::chev1;
	// IF DEGREE IS QUADRATIC, N MUST BE EVEN
	Degree polydegree = Degree::cubic;
	Order meshorder = Order::increasing;
	BoundaryCon condition = BoundaryCon::double_prime;
	std::vector<double> mesh(build_mesh(meshtype, n, left_end, right_end));
	bubble_sort(mesh, meshorder);
	std::vector<double> y(y_calculator(mesh, f1));
	std::vector<float> mesh_sp(mesh.size());
	for (size_t i = 0; i < mesh_sp.size(); i++)
	{
		mesh_sp.at(i) = static_cast<float>(mesh.at(i));
	}
	
	std::vector<float> y_sp(y_calculator(mesh_sp, f1));

	size_t first_entry = 0;

	/*std::cout << "Corresponding (x, y) pairs are: " << std::endl;
	for (size_t i = 0; i < mesh.size(); i++)
	{
		std::cout << "(" << mesh.at(i) << ", " << y.at(i) << ")" << std::endl;
	}

	double x;
	std::cout << "Enter a value for x to interpolate for the function. x = ";
	std::cin >> x;
	
	while (x > right_end || x < left_end)
	{
		std::cout << "Enter a value within the interval [" << left_end << "," << right_end << "] :";
		std::cin >> x;
	}
	float x_sp = static_cast<float>(x);
	
	
	
	size_t x_i = binary_search(polydegree, mesh, first_entry, mesh.size(), x_sp);
	if (polydegree == Degree::linear)
	{
		std::cout << "We are locally interpolating on : [" << mesh.at(x_i) << ", " << mesh.at(x_i + 1) << "]" << std::endl;
	}
	if (polydegree == Degree::quadratic)
	{
		std::cout << "We are locally interpolating on : [" << mesh.at(x_i) << ", " << mesh.at(x_i + 2) << "]" << std::endl;
	}
	if (polydegree == Degree::cubic)
	{
		std::cout << "We are locally interpolating on : [" << mesh.at(x_i) << ", " << mesh.at(x_i + 1) << "]" << std::endl;
	}
	float interp_x = p_i(polydegree, x_i, x_sp, mesh_sp, y_sp, condition);
	std::cout << "The interpolated value of f(x) = " << interp_x << std::endl
		<< "The true value for f(x) = " << f1(x) << std::endl;*/

	std::ofstream myfile;
	myfile.open("values.txt");
	std::vector<double> interp_values(N);
	std::vector<double> true_values(interp_values.size());
	for (size_t i = 0; i < interp_values.size(); i++)
	{
		interp_values.at(i) = rand_gen(mesh.at(0), mesh.at(n - 1));
		true_values.at(i) = f1(interp_values.at(i));
	}
	std::vector<float> interp_val_sp(interp_values.size());
	std::vector<float> interpolated(interp_val_sp.size());
	for (size_t i = 0; i < interp_val_sp.size(); i++)
	{
		interp_val_sp.at(i) = static_cast<float>(interp_values.at(i));
		size_t index = binary_search(polydegree, mesh, first_entry, mesh.size(), interp_val_sp.at(i));
		interpolated.at(i) = p_i(polydegree, index, interp_val_sp.at(i), mesh_sp, y_sp, condition);
		myfile << interp_val_sp.at(i) << " " << interpolated.at(i) << std::endl;
	}
	
	double inf_norm = infinity_norm(true_values, interpolated);

	std::cout << inf_norm << std::endl;


}

double f1(double x)
{
	return x / (3 * pow(x, 3) + 1);
}
float f1(float x)
{
	return (x) / (3 * pow(x, 3) + 1);
}

