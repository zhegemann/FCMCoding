#pragma once
#ifndef MY_FUNCTION_H
#define MY_FUNCTION_H
#include <vector>
#include <cmath>
#include <algorithm>
enum class BoundaryCon
{
	prime,
	double_prime
};

enum class Degree
{
	linear,
	quadratic,
	cubic
};

enum class Mesh
{
	uniform,
	chev1,
	chev2
};

enum class Order
{
	increasing,
	decreasing,
	leja
};


// Generates the midpoints of  a vector of size n and returns them in a vector of size n-1
template<typename T>
std::vector<T> gen_midpoints(std::vector<T> mesh);

// Midpoint quadrature for a function f
template<typename T>
T integrate_cmp(Mesh meshtype, T left_end, T right_end, size_t m, T (*f)(T));

//Trapezoidal quadrature for a function f
template<typename T>
T integrate_ctr(Mesh meshtype, T left_end, T right_end, size_t m, T(*f)(T));

// Refines the mesh of the trapezoidal quadrature for a function f by 2
template<typename T>
T halfstep_ctr(Mesh meshtype, T left_end, T right_end, size_t m, T(*f)(T));

// Piecewise polynomial interpolation of the interval [x_i, x_{i+1}]
float p_i(Degree degree, size_t i, float x_sp, std::vector<float> mesh_sp, std::vector<float> y_sp, BoundaryCon condition);

// Generates the tail end, gamma, of the interpolating polynomial p_i
float gamma(std::vector<float> y, std::vector<float> s_deriv, std::vector<float> h, size_t i);

// Generates the tail end, gamma tilde, of the interpolating polynomial p_i
float gamma_tilde(std::vector<float> y, std::vector<float> s_deriv, std::vector<float> h, size_t i);

// Binary search to find which interval [x_i, x_{i+1}] the paramater, x, lies in
int binary_search(Degree degree, std::vector<double> vec, int left, int right, double x);

// Generates the x_i set of data given a mesh type, input size, left endpoint, and right endpoint in double precision
std::vector<double> build_mesh(Mesh type, size_t n, double left_endpoint, double right_endpoint);

// Generates the x_i set of data given a mesh type, input size, left endpoint, and right endpoint in single precision
std::vector<float> build_mesh(Mesh type, size_t n, float left_endpoint, float right_endpoint);

// Generates the x_i set of data given a mesh type, input size, left endpoint, and right endpoint in T precision
template <typename T>
std::vector<T> build_mesh(Mesh type, size_t n, T left_endpoint, T right_endpoint);

// Calculate the vector y_i given a vector of x_i and a function
std::vector<double> y_calculator(std::vector<double> x_i, double (*f)(double));

// Calculate the vector y_i given a vector of x_i and a function
std::vector<float> y_calculator(std::vector<float> x_i, float (*f)(float));

// Orders the mesh points
void x_ordering(std::vector<double> x, Order order);

// Orders the mesh points
void x_ordering(std::vector<float> x, Order order);

// Swap two doubles
void swap(double* first, double* second);

// A function to implement bubble sort on an array of doubles
void bubble_sort(std::vector<double>& vec, Order order);

// Swap two floats
void swap(float* first, float* second);

// A function to implement bubble sort on an array of floats
void bubble_sort(std::vector<float>& vec, Order order);

// The Leja ordering for a vector of doubles
std::vector<double> leja_d(std::vector<double> x);

// The Leja ordering for a vector of floats
std::vector<float> leja_f(std::vector<float> x);

// Returns the index of the largest element for a vector of doubles
size_t max_index(std::vector<double> vec);

// Returns the index of the largest element for a vector of doubles
size_t max_index(std::vector<float> vec);

// Determines the pointwise error given the values for polynomial p(x) and interpolated points {y}
std::vector<double> pointwise_error(std::vector<double> p, std::vector<float> y);

// Finds the infinity norm of a vector
double infinity_norm(std::vector<double> p, std::vector<float> y);

/* Thomas' Algorithm
* This function takes in 5 vectors: mu, diag, lambda, s_deriv, d
* mu holds the lower off diagonal values, diag holds the values on the diagonal, and lambda 
* holds the upper off diagonal values. s_deriv holds the values of s' or s''.
*/
void thom_alg(const std::vector<float>& lambda, const std::vector<float>& diag, const std::vector<float>& mu, const std::vector<float>& d,
	std::vector<float>& s_deriv);

// Calculates the distance between subsequent mesh points x_i and x_{i-1}
std::vector<float> h(std::vector<float> mesh);

// Generates the superdiagonal vector, lambda
std::vector<float> superdiagonal(std::vector<float> mesh, std::vector<float> h);

// Generates the subdiagonal vector, mu
std::vector<float> subdiagonal(std::vector<float> mesh, std::vector<float> h);

// Generates the vector d
std::vector<float> generate_d(std::vector<float> f, std::vector<float> mesh, std::vector<float> h, const size_t N);

// Sets up a table of divided differences based on two vectors x and y in single precision
void divided_differences(size_t n, std::vector<float> x, std::vector<float> y, std::vector<float>& div_diff_table, Order ordering);

// Generates random numbers between two endpoints
double rand_gen(double min, double max);

// Sums all values of a vector
template<typename T>
T sum_val(std::vector<T> vec);

// END FCM1 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

// FCM2 DECLARATIONS





// FCM1 DEFINITIONS

template<typename T>
std::vector<T> gen_midpoints(std::vector<T> mesh)
{
	std::vector<T> midpoints(mesh.size() - 1);
	for (size_t i = 0; i < mesh.size() - 1; i++)
	{
		midpoints.at(i) = mesh.at(i) + (mesh.at(i + 1) - mesh.at(i)) / 2;
	}
	return midpoints;
}

template<typename T>
T integrate_cmp(Mesh meshtype, T left_end, T right_end, size_t m, T(*f)(T))
{
	T h_m = (right_end - left_end) / m;
	std::vector<T> midpoints(std::vector<T>(build_mesh(meshtype, m, left_end, right_end)));
	std::vector<T> f_i(y_calculator(midpoints, f));
	return h_m * sum_val(f_i);
}


template<typename T>
T integrate_ctr(Mesh meshtype, T left_end, T right_end, size_t m, T(*f)(T))
{
	T h_m = (right_end - left_end) / m; 
	std::vector<T> mesh(build_mesh(meshtype, m, left_end, right_end));
	std::vector<T> f_i(y_calculator(mesh, f));
	return h_m / 2 * (f_i.at(0) + f_i.at(m - 1) + 2 * (sum_val(f_i) - f_i.at(0) - f_i.at(m - 1)));
}

template<typename T>
T halfstep_ctr(Mesh meshtype, T left_end, T right_end, size_t m, T(*f)(T))
{
	T h_m = (right_end - left_end / m);
	std::vector<T> midpoints(std::vector<T>(build_mesh(meshtype, m, left_end, right_end)));
	return 0.5 * (integrate_ctr(meshtype, left_end, right_end, m, f) + integrate_cmp(meshtype, left_end, right_end, m, f));
}

/* float p_i(Degree degree, size_t i, float x_sp, std::vector<float> mesh_sp, std::vector<float> y_sp, BoundaryCon condition)
{
	const size_t N = mesh_sp.size();
	if (degree == Degree::linear)
	{
		return (y_sp.at(i) * (mesh_sp.at(i + 1) - x_sp) + y_sp.at(i + 1) * (x_sp - mesh_sp.at(i))) / (mesh_sp.at(i + 1) - mesh_sp.at(i));
	}
	if (degree == Degree::quadratic)
	{
		return (y_sp.at(i) * (x_sp - mesh_sp.at(i + 1)) * (x_sp - mesh_sp.at(i + 2))
			/ ((mesh_sp.at(i) - mesh_sp.at(i + 1)) * (mesh_sp.at(i) - mesh_sp.at(i + 2))))
				+ 
				(y_sp.at(i + 1) * (x_sp - mesh_sp.at(i)) * (x_sp - mesh_sp.at(i + 2))
					/ ((mesh_sp.at(i + 1) - mesh_sp.at(i)) * (mesh_sp.at(i + 1) - mesh_sp.at(i + 2))))
				+
				(y_sp.at(i + 2) * (x_sp - mesh_sp.at(i)) * (x_sp - mesh_sp.at(i + 1))
					/ ((mesh_sp.at(i + 2) - mesh_sp.at(i)) * (mesh_sp.at(i + 2) - mesh_sp.at(i + 1))));
	}
	if (degree == Degree::cubic)
	{
		if (condition == BoundaryCon::double_prime)
		{
			std::vector<float> s_i(N);
			std::vector<float> diag(N  - 2);
			for (size_t i = 0; i < N - 2; i++)
			{
				diag.at(i) = 2;
			}
			std::vector<float> h(h(mesh_sp));
			std::vector<float> lambda(superdiagonal(mesh_sp, h));
			std::vector<float> mu(subdiagonal(mesh_sp, h));
			std::vector<float> d(generate_d(y_sp, mesh_sp, h, N - 2));
			thom_alg(lambda, diag, mu, d, s_i);
			return s_i.at(i) * pow((mesh_sp.at(i + 1) - x_sp), 3) / 6 * h.at(i) + s_i.at(i + 1) * pow((x_sp - mesh_sp.at(i)), 3) / 6 * h.at(i)
				+ gamma(y_sp, s_i, h, i) * (x_sp - mesh_sp.at(i)) + gamma_tilde(y_sp, s_i, h, i);
		}
		return 1;
	}
	return 1;
}
*/
float gamma(std::vector<float> y, std::vector<float> s_deriv, std::vector<float> h, size_t i)
{
	return (y.at(i + 1) - y.at(i)) / h.at(i) - h.at(i) / 6 * (s_deriv.at(i + 1) - s_deriv.at(i));
}

float gamma_tilde(std::vector<float> y, std::vector<float> s_deriv, std::vector<float> h, size_t i)
{
	return y.at(i) - s_deriv.at(i) * h.at(i) / 6;
}

int binary_search(Degree degree, std::vector<double> vec, int left, int right, double x)
{
	const double EPSILON = 0.00000000001;
	if (degree == Degree::linear)
	{
		while (left != right)
		{
			int mid = (left + right) / 2;
			if (vec.at(mid) <= x)
			{
				left = mid + 1;
			}
			else
			{
				right = mid;
			}
		}
		return right - 1;
	}
	if (degree == Degree::quadratic)
	{
		while (left != right)
		{
			int mid = (left + right) / 2;
			if (vec.at(mid) <= x)
			{
				left = mid + 1;
			}
			else
			{
				right = mid;
			}
		}
		if (right == vec.size() - 1)
		{
			return right - 2;
		}
		else
		{
			return right - 1;
		}
		
	}
	if (degree == Degree::cubic)
	{
		while (left != right)
		{
			int mid = (left + right) / 2;
			if (vec.at(mid) <= x)
			{
				left = mid + 1;
			}
			else
			{
				right = mid;
			}
		}
		return right - 1;
	}
	return -1;
}

std::vector<double> build_mesh(Mesh type, size_t n, double left_endpoint, double right_endpoint)
{
	std::vector<double> x(n);
	double x_i;
	if (type == Mesh::uniform)
	{
		double h = (right_endpoint - left_endpoint) / (n - 1);
		for (size_t i = 0; i < n; i++)
		{
			x_i = left_endpoint + (i * h);
			x.at(i) = x_i;
		}
	}
	else if (type == Mesh::chev1)
	{
		const double pi = 3.141592653589793;
		double angle;
		for (size_t i = 0; i < n; i++)
		{
			angle = (2 * (static_cast<double>(i) + 1)) * pi / (2 * (static_cast<double>(n) + 2));
			x_i = cos(angle);
			x_i = 0.5 * (left_endpoint + right_endpoint) + x_i * 0.5 * (left_endpoint - right_endpoint);
			x.at(i) = x_i;
		}
	}
	else
	{
		const double pi = 3.141592653589793;
		double angle;
		for (size_t i = 0; i < n; i++)
		{
			angle = static_cast<double>(i * pi) / n;
			x_i = cos(angle);
			x_i = 0.5 * (left_endpoint + right_endpoint) + x_i * 0.5 * (left_endpoint - right_endpoint);
			x.at(i) = x_i;
		}
	}
	return x;
}

std::vector<float> build_mesh(Mesh type, size_t n, float left_endpoint, float right_endpoint)
{
	std::vector<float> x(n);
	float x_i;
	if (type == Mesh::uniform)
	{
		float h = (right_endpoint - left_endpoint) / (n - 1);
		for (size_t i = 0; i < n; i++)
		{
			x_i = left_endpoint + (i * h);
			x.at(i) = x_i;
		}
	}
	else if (type == Mesh::chev1)
	{
		const float pi = 3.14159F;
		float angle;
		for (size_t i = 0; i < n; i++)
		{
			angle = (static_cast<float>(2) * (i + 1)) * pi / (static_cast<float>(2) * (n + 2));
			x_i = cos(angle);
			x_i = 0.5F * (left_endpoint + right_endpoint) + x_i * 0.5F * (left_endpoint - right_endpoint);
			x.at(i) = x_i;
		}
	}
	else
	{
		const float pi = 3.14159F;
		float angle;
		for (size_t i = 0; i < n; i++)
		{
			angle = static_cast<float>(i * pi) / n;
			x_i = cos(angle);
			x_i = 0.5F * (left_endpoint + right_endpoint) + x_i * 0.5F * (left_endpoint - right_endpoint);
			x.at(i) = x_i;
		}
	}
	return x;
}

template<typename T>
std::vector<T> build_mesh(Mesh type, size_t n, T left_endpoint, T right_endpoint)
{
	std::vector<T> x(n);
	T x_i;
	if (type == Mesh::uniform)
	{
		T h = (right_endpoint - left_endpoint) / (n - 1);
		for (size_t i = 0; i < n; i++)
		{
			x_i = left_endpoint + (i * h);
			x.at(i) = x_i;
		}
	}
	else if (type == Mesh::chev1)
	{
		const T pi = 3.14159F;
		T angle;
		for (size_t i = 0; i < n; i++)
		{
			angle = (static_cast<T>(2) * (i + 1)) * pi / (static_cast<T>(2) * (n + 2));
			x_i = cos(angle);
			x_i = 0.5F * (left_endpoint + right_endpoint) + x_i * 0.5F * (left_endpoint - right_endpoint);
			x.at(i) = x_i;
		}
	}
	else
	{
		const T pi = 3.14159F;
		T angle;
		for (size_t i = 0; i < n; i++)
		{
			angle = static_cast<T>(i * pi) / n;
			x_i = cos(angle);
			x_i = 0.5F * (left_endpoint + right_endpoint) + x_i * 0.5F * (left_endpoint - right_endpoint);
			x.at(i) = x_i;
		}
	}
	return x;
}

std::vector<double> y_calculator(std::vector<double> x_i, double (*f)(double))
{
	double y_i;
	std::vector<double>y(x_i.size());
	for (size_t i = 0; i < y.size(); i++)
	{
		y_i = f(x_i.at(i));
		y.at(i) = y_i;
	}
	return y;
}

std::vector<float> y_calculator(std::vector<float> x_i, float (*f)(float))
{
	float y_i;
	std::vector<float>y(x_i.size());
	for (size_t i = 0; i < y.size(); i++)
	{
		y_i = f(x_i.at(i));
		y.at(i) = y_i;
	}
	return y;
}

void x_ordering(std::vector<double> x, Order order)
{
	if (order == Order::increasing)
	{
		bubble_sort(x, order);
	}
	else if (order == Order::decreasing)
	{
		bubble_sort(x, order);
	}
	else
	{
		leja_d(x);
	}
}

void x_ordering(std::vector<float> x, Order order)
{
	if (order == Order::increasing)
	{
		bubble_sort(x, order);
	}
	else if (order == Order::decreasing)
	{
		bubble_sort(x, order);
	}
	else
	{
		leja_f(x);
	}
}

void swap(double* first, double* second)
{
	double temp = *first;
	*first = *second;
	*second = temp;
}

void bubble_sort(std::vector<double>& vec, Order order)
{
	if (order == Order::increasing)
	{
		for (size_t i = 0; i < vec.size(); i++)
		{
			for (size_t j = 0; j < vec.size() - 1; j++)
			{
				if (vec.at(j) > vec.at(j + 1))
				{
					swap(&vec.at(j), &vec.at(j + 1));
				}
			}

		}
	}
	else
	{
		for (size_t i = 0; i < vec.size(); i++)
		{
			for (size_t j = 0; j < vec.size() - 1; j++)
			{
				if (vec.at(j) < vec.at(j + 1))
				{
					swap(&vec.at(j), &vec.at(j + 1));
				}
			}

		}
	}

}

void swap(float* first, float* second)
{
	float temp = *first;
	*first = *second;
	*second = temp;
}

void bubble_sort(std::vector<float>& vec, Order order)
{
	if (order == Order::increasing)
	{
		for (size_t i = 0; i < vec.size(); i++)
		{
			for (size_t j = 0; j < vec.size() - 1; j++)
			{
				if (vec.at(j) > vec.at(j + 1))
				{
					swap(&vec.at(j), &vec.at(j + 1));
				}
			}

		}
	}
	else
	{
		for (size_t i = 0; i < vec.size(); i++)
		{
			for (size_t j = 0; j < vec.size() - 1; j++)
			{
				if (vec.at(j) < vec.at(j + 1))
				{
					swap(&vec.at(j), &vec.at(j + 1));
				}
			}

		}
	}
}

std::vector<double> leja_d(std::vector<double> x)
{
	// A vector of the magnitudes of x
	std::vector<double> abs_x_i;
	abs_x_i.resize(x.size());
	for (size_t i = 0; i < x.size(); i++)
	{
		abs_x_i.at(i) = abs(x.at(i));
	}

	std::vector<double> leja_ordering;
	leja_ordering.resize(x.size());
	double x_max = 0;

	// Find the largest magnitude of x
	for (size_t i = 0; i < x.size(); i++)
	{
		if (abs_x_i.at(i) > x_max)
		{
			leja_ordering.at(0) = x.at(i);
		}
	}
	// Vector to hold the 0th to j-1th products to compare and find the largest
	std::vector<double> products_x_i;
	products_x_i.resize(x.size());

	// For loop to perform leja ordering
	for (size_t i = 1; i < x.size(); i++)
	{
		double running_product = 1;
		for (size_t j = 0; j < x.size(); j++)
		{
			for (size_t k = 0; k < i; k++)
			{
				running_product = running_product * abs((x.at(j) - leja_ordering.at(k)));
			}
			products_x_i.at(j) = running_product;
			running_product = 1;
		}
		leja_ordering.at(i) = x.at(max_index(products_x_i));

	}
	return leja_ordering;
}

std::vector<float> leja_f(std::vector<float> x)
{
	// A vector of the magnitudes of x
	std::vector<float> abs_x_i;
	abs_x_i.resize(x.size());
	for (size_t i = 0; i < x.size(); i++)
	{
		abs_x_i.at(i) = abs(x.at(i));
	}

	std::vector<float> leja_ordering;
	leja_ordering.resize(x.size());
	float x_max = 0;

	// Find the largest magnitude of x
	for (size_t i = 0; i < x.size(); i++)
	{
		if (abs_x_i.at(i) > x_max)
		{
			leja_ordering.at(0) = x.at(i);
		}
	}
	// Vector to hold the 0th to j-1th products to compare and find the largest
	std::vector<float> products_x_i;
	products_x_i.resize(x.size());

	// For loop to perform leja ordering
	for (size_t i = 1; i < x.size(); i++)
	{
		float running_product = 1;
		for (size_t j = 0; j < x.size(); j++)
		{
			for (size_t k = 0; k < i; k++)
			{
				running_product = running_product * abs((x.at(j) - leja_ordering.at(k)));
			}
			products_x_i.at(j) = running_product;
			running_product = 1;
		}
		leja_ordering.at(i) = x.at(max_index(products_x_i));

	}
	return leja_ordering;
}

size_t max_index(std::vector<double> vec)
{
	size_t max_index = 0;
	for (size_t i = 0; i < vec.size(); i++)
	{
		if (vec.at(i) > vec.at(max_index))
		{
			max_index = i;
		}
	}
	return max_index;
}

size_t max_index(std::vector<float> vec)
{
	size_t max_index = 0;
	for (size_t i = 0; i < vec.size(); i++)
	{
		if (vec.at(i) > vec.at(max_index))
		{
			max_index = i;
		}
	}
	return max_index;
}

std::vector<double> pointwise_error(std::vector<double> p, std::vector<float> y)
{
	std::vector<double> error;
	error.resize(p.size());
	for (size_t i = 0; i < p.size(); i++)
	{
		error.at(i) = abs(p.at(i) - y.at(i));
	}
	return error;
}

double infinity_norm(std::vector<double> p, std::vector<float> y)
{
	std::vector<double> error = pointwise_error(p, y);
	return *max_element(error.begin(), error.end());
}

void thom_alg(const std::vector<float>& lambda, const std::vector<float>& diag, const std::vector<float>& mu, const std::vector<float>& d,
	std::vector<float>& s_deriv)
{
	std::vector<float> temp_lambda(diag.size());
	std::vector<float> temp_d(diag.size());

	// Set initial temp_.at(0) values
	temp_lambda.at(0) = lambda.at(0) / diag.at(0);
	temp_d.at(0) = d.at(0) / diag.at(0);

	// Create the rest of the mu and d coefficients 
	for (size_t i = 1; i < d.size(); i++)
	{
		temp_lambda.at(i) = lambda.at(i) / (diag.at(i) - mu.at(i) * temp_lambda.at(i - 1));
		temp_d.at(i) = (d.at(i) - mu.at(i) * temp_d.at(i - 1)) / (diag.at(i) - mu.at(i) * temp_lambda.at(i - 1));
	}

	// Update the solution to the vector s_deriv
	for (size_t i = s_deriv.size() - 2; i > 0; i--)
	{
		s_deriv.at(i) = temp_d.at(i - 1) - temp_lambda.at(i - 1) * s_deriv.at(i + 1);

	}
}

std::vector<float> h(std::vector<float> mesh)
{
	std::vector<float> h(mesh.size() - 1);
	for (size_t i = 0; i < h.size(); i++)
	{
		h.at(i) = mesh.at(i + 1) - mesh.at(i);
	}
	return h;
}

std::vector<float> superdiagonal(std::vector<float> mesh, std::vector<float> h)
{
	std::vector<float> lambda(h.size() - 1);
	for (size_t i = 0; i < mesh.size() - 2; i++)
	{
		lambda.at(i) = h.at(i + 1) / (h.at(i) + h.at(i + 1));
	}
	return lambda;
}

std::vector<float> subdiagonal(std::vector<float> mesh, std::vector<float> h)
{
	std::vector<float> mu(h.size() - 1);
	for (size_t i = 0; i < mesh.size() - 2; i++)
	{
		mu.at(i) = h.at(i) / (h.at(i) + h.at(i + 1));
	}
	return mu;
}

std::vector<float> generate_d(std::vector<float> f, std::vector<float> mesh, std::vector<float> h, const size_t N)
{	
	std::vector<float> d(mesh.size() - 2);
	for (size_t i = 0; i < N; i++)
	{
		d.at(i) = (6 / (h.at(i) + h.at(i + 1))) * (((f.at(i + 2) - f.at(i + 1)) / h.at(i + 1) - (f.at(i + 1) - f.at(i)) / h.at(i)));
	}


	return d;
}

void divided_differences(size_t n, std::vector<float> x, std::vector<float> y, std::vector<float>& div_diff_table, Order ordering)
{
	if (ordering == Order::decreasing)
	{
		x_ordering(x, Order::decreasing);
	}
	else if (ordering == Order::increasing)
	{
		x_ordering(x, Order::increasing);
	}
	else
	{
		x_ordering(x, Order::leja);
	}
	div_diff_table.resize(n * n);
	for (size_t i = 0; i < n; i++)
	{
		div_diff_table.at(i) = y.at(i);
	}
	for (size_t i = 1; i < n; i++)
	{
		for (size_t k = i * n; k < i * n + (n - i); k++)
		{
			div_diff_table.at(k) = (div_diff_table.at(k - (n - 1)) - div_diff_table.at(k - n))
				/ (x.at(k - (i * n) + i) - x.at(k - (n * i)));
		}
	}
}

double rand_gen(double min, double max)
{
	double rand_num = (double)rand() / RAND_MAX;
	return min + rand_num * (max - min);
}

template<typename T>
T sum_val(std::vector<T> vec)
{
	T sum = 0;
	for (size_t i = 0; i < vec.size(); i++)
	{
		sum += vec.at(i);
	}
	return sum;
}

// END FCM1 DEFINITIONS ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^


#endif