// HW2.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <chrono>
#include <fstream>
#include <complex>
#include <iomanip>
#include "dftfft.h"
#include "interp.h"
#include <valarray>
#include <time.h>
using namespace std::chrono;

int main()
{
   
    srand(time(NULL));
    bool invert = false;
    size_t N = 5;
    double min = -1000.0;
    double max = 1000.0;
    size_t num_vecs = 16;
    

    std::vector<std::vector<std::complex<double>>> circ{
        {1, 2, 3},
        {2, 3, 1},
        {3, 1, 2}
    };

    std::vector<std::complex<double>> b{ 1, 1, 2 };

    std::vector<std::complex<double>> x(circ_lin_sys(circ, b));

    display_vec(x);

//    std::ofstream myfile;
//std::ofstream myotherfile;
//myfile.open("DFT_times.dat");
//myotherfile.open("FFT_times.dat");


    /*myfile.close();
    myotherfile.close();
    std::cout << std::endl; */ 

        return 0;
}

//std::cout << "DFT Times: " << std::endl;
//for (size_t i = 0; i < num_vecs; i++)
//{
//    std::vector<std::complex<double>> vec(gen_vec(pow(2, i), min, max));
//    auto start = high_resolution_clock::now();
//    std::vector<std::complex<double>> DFTvec(DFT(vec, invert));
//    auto stop = high_resolution_clock::now();
//    auto duration = duration_cast<microseconds>(stop - start);
//    std::cout << pow(2, i) << " " << duration.count() << std::endl;
//    vec.clear();
//}
//
//std::cout << std::endl << "FFT Times: " << std::endl;
//
//for (size_t i = 0; i < num_vecs; i++)
//{
//    std::vector<std::complex<double>> vec(gen_vec(pow(2, i), min, max));
//    auto start = high_resolution_clock::now();
//    std::vector<std::complex<double>> FFTvec(unit_FFT(vec, invert));
//    auto stop = high_resolution_clock::now();
//    auto duration = duration_cast<microseconds>(stop - start);
//    std::cout << pow(2, i) << " " << duration.count() << std::endl;
//    vec.clear();
//}

//std::vector<std::vector<std::complex<double>>> ranvecs(gen_vecvecFFT(min, max, num_vecs));
//
//std::vector<std::vector<std::complex<double>>> DFTranvecs(DFT_vecvec(ranvecs, invert));
//std::vector<std::vector<std::complex<double>>> FFTranvecs(FFT_vecvec(ranvecs, invert));
//
//
//invert = true;
//std::vector<std::vector<std::complex<double>>> IDFTDFTranvecs(DFT_vecvec(DFTranvecs, invert));
//std::vector<std::vector<std::complex<double>>> IFFTFFTranvecs(FFT_vecvec(DFTranvecs, invert));
//
//std::vector<double> norms(gen_norms(ranvecs));
//std::vector<double> DFTnorms(gen_norms(DFTranvecs));
//std::vector<double> FFTnorms(gen_norms(FFTranvecs));
//
//
//std::vector<size_t> vec_lengths(get_lengths(ranvecs));
//
//std::ofstream myfile;
//myfile.open("DFTnorm_error.dat");
//std::ofstream otherfile;
//otherfile.open("FFTnorm_error.dat");
//
//std::vector<double> DFTinf_normlist(inf_norms(ranvecs, IDFTDFTranvecs));
//std::vector<double> FFTinf_normlist(inf_norms(ranvecs, IFFTFFTranvecs));
//
//for (size_t i = 0; i < DFTinf_normlist.size(); i++)
//{
//    myfile << log2(vec_lengths[i]) << " " << log10(abs(DFTnorms[i] - norms[i])) << std::endl;
//    otherfile << log2(vec_lengths[i]) << " " << log10(abs(FFTnorms[i] - norms[i])) << std::endl;
//}



//std::vector<std::complex<double>> ranvec(gen_vec(N, min, max));
//display_vec(ranvec);
//
//std::vector<std::complex<double>> dftranvec(DFT(ranvec, invert));
//
//display_vec(dftranvec);
//
//invert = true;
//std::vector<std::complex<double>> iranvec(DFT(dftranvec, invert));
//
//display_vec(iranvec);
//
//double normdiff = two_norm(ranvec) - two_norm(iranvec);
//
//std::cout << normdiff;

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
