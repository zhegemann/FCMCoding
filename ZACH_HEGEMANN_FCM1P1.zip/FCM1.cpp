#include <iostream>
#include <vector>
#include <iomanip>
#include <string>
#include <math.h>

// Double accumulation summation that receives a vector of doubles
double exact_accumulation(std::vector<double> double_vector);

// Recusive sum that receives a vector of floats
float float_accumulation(std::vector<float> float_vector);

// Binary fan-in summation that receives a vector of floats
float fan_in(std::vector<float> float_vector);

// Double accumulation summation that receives a vector of floats
float double_accumulation(std::vector<float> float_vector);

// Finds the error between two terms
double find_error(double sum1, double sum2);

int main()
{
    std::cout << "Building arrays of doubles... " << std::endl;
    std::cout << std::setprecision(16);
    std::vector<double> XI_DP1;
    XI_DP1.push_back(0.12345);
    XI_DP1.push_back(0.2555567701);
    XI_DP1.push_back(0.45676543);
    XI_DP1.push_back(.22);
    XI_DP1.push_back(.197230112);
    XI_DP1.push_back(.8654387657463);
    XI_DP1.push_back(.105);
    XI_DP1.push_back(.2311454657478986);

    std::cout << "Exact precision accumulation of XI_DP1: " << exact_accumulation(XI_DP1) << std::endl;

    std::vector<float> XI_SP1 (XI_DP1.size());
    for (size_t i = 0; i < XI_DP1.size(); i++)
    {
        XI_SP1.at(i) = static_cast<float> (XI_DP1.at(i));
    }
    
    std::cout << "Single precision fan in of XI_SP1: " << fan_in(XI_SP1) << std::endl;
    std::cout << "Single precision accumulation of XI_SP1: " << float_accumulation(XI_SP1) << std::endl;
    std::cout << "Double precision accumulation of XI_SP1: " << double_accumulation(XI_SP1) << std::endl;
    double e_XI_SP1 = static_cast<double> (double_accumulation(XI_SP1));
    std::cout << "The error between the algorithm sums and true sum is: " << find_error(static_cast<double> (fan_in(XI_SP1)), e_XI_SP1) << std::endl << std::endl;

    std::cout << std::setprecision(12);
    std::vector<double> XI_DP2 (32);
    
    for (size_t i = 0; i < XI_DP2.size(); i++)
    {
        XI_DP2.at(i) = pow(-1, i) * 1 / (pow(i + 1, 2));
    }
    

    std::cout << "Exact precision accumulation of XI_DP2: " << exact_accumulation(XI_DP2) << std::endl;

    
    std::vector<float> XI_SP2 (XI_DP2.size());
    for (size_t i = 0; i < XI_DP2.size(); i++)
    {
        XI_SP2.at(i) = static_cast<float> (XI_DP2.at(i));
    }

    std::cout << "Single precision fan in of XI_SP2: " << fan_in(XI_SP2) << std::endl;
    std::cout << "Single precision accumulation of XI_SP2: " << float_accumulation(XI_SP2) << std::endl;
    std::cout << "Double precision accumulation of XI_SP2: " << double_accumulation(XI_SP2) << std::endl;
         double e_XI_SP2 = static_cast<double> (double_accumulation(XI_SP2));
    std::cout << "The error between the algorithm sums and true sum is: " << find_error(static_cast<double> (fan_in(XI_SP2)), e_XI_SP2) << std::endl << std::endl;

    std::vector<double> XI_DP3 (32);
    
    for (size_t i = 0; i < XI_DP3.size(); i++)
    {
        XI_DP3.at(i) = pow(-1, i) * 3 / (pow(i + 1, 3));
    }

    std::cout << "Exact precision accumulation of XI_DP3: " << exact_accumulation(XI_DP3) << std::endl;

    std::vector<float> XI_SP3 (XI_DP3.size());
    for (size_t i = 0; i < XI_DP3.size(); i++)
    {
        XI_SP3.at(i) = static_cast<float> (XI_DP3.at(i));
    }

    std::cout << "Single precision fan in of XI_SP3: " << fan_in(XI_SP3) << std::endl;
    std::cout << "Single precision accumulation of XI_SP3: " << float_accumulation(XI_SP3) << std::endl;
    std::cout << "Double precision accumulation of XI_SP3: " << double_accumulation(XI_SP3) << std::endl;
    double e_XI_SP3 = static_cast<double> (double_accumulation(XI_SP3));
    std::cout << "The error between the algorithm sums and true sum is: " << find_error(static_cast<double> (fan_in(XI_SP3)), e_XI_SP3) << std::endl << std::endl;

    std::vector<double> XI_DP4 (64);
    
    for (size_t i = 0; i < XI_DP4.size(); i++)
    {
        XI_DP4.at(i) = pow(-1, i) * 1 / (pow(2 * i + 1, 5));
    }

    std::cout << "Exact precision accumulation of XI_DP4: " << exact_accumulation(XI_DP4) << std::endl;
    
    std::vector<float> XI_SP4 (XI_DP4.size());
    for (size_t i = 0; i < XI_DP4.size(); i++)
    {
        XI_SP4.at(i) = static_cast<float> (XI_DP4.at(i));
    }

    std::cout << "Single precision fan in of XI_SP4: " << fan_in(XI_SP4) << std::endl;
    std::cout << "Single precision accumulation of XI_SP4: " << float_accumulation(XI_SP4) << std::endl;
    std::cout << "Double precision accumulation of XI_SP4: " << double_accumulation(XI_SP4) << std::endl;
    double e_XI_SP4 = static_cast<double> (double_accumulation(XI_SP4));
    std::cout << "The error between the algorithm sums and true sum is: " << find_error(static_cast<double> (fan_in(XI_SP4)), e_XI_SP4) << std::endl << std::endl;

    std::vector<double> XI_DP5 (128);
    
    for (size_t i = 0; i < XI_DP5.size(); i++)
    {
        XI_DP5.at(i) = pow(-1, i) * 9 / (pow(3 * i + 1, 7));
    }

    std::cout << "Exact precision accumulation of XI_DP5: " << exact_accumulation(XI_DP5) << std::endl;
    
    return 0;
}

double exact_accumulation(std::vector<double> double_vector)
{
    size_t vec_size = double_vector.size();
    double accumulated_sum = 0;
    for (size_t i = 0; i < vec_size; i++)
    {
        accumulated_sum += double_vector.at(i);
    }
    return accumulated_sum;
}

float float_accumulation(std::vector<float> float_vector)
{
    size_t vec_size = float_vector.size();
    float accumulated_sum = 0;
    for (size_t i = 0; i < vec_size; i++)
    {
        accumulated_sum += float_vector.at(i);
    }
    return accumulated_sum;
}

float fan_in(std::vector<float> float_vector)
{
   if(float_vector.size() == 1)
   {
       return float_vector.at(0);
   }
   else
   {
       std::vector<float> dummy;
    for (size_t i = 0; i < float_vector.size(); i += 2)
    {
        dummy.push_back(float_vector.at(i) + float_vector.at(i + 1));
    }
    return fan_in(dummy);     
   }
       
}

float double_accumulation(std::vector<float> float_vector)
{
    std::vector<double> dummy (float_vector.size());
    for (size_t i = 0; i < float_vector.size(); i++)
    {
        dummy.at(i) = static_cast<double> (float_vector.at(i));
    }

    double sum = 0;
    for (size_t i = 0; i < dummy.size(); i++)
    {
        sum += dummy.at(i);
    }
    return static_cast<float> (sum);
}

double find_error(double sum1, double sum2)
{
    return (abs(sum1 - sum2));
}