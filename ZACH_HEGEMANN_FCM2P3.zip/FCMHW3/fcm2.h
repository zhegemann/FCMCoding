#pragma once
#ifndef MY_FUNCTION_H
#define MY_FUNCTION_H
#include <vector>
#include <valarray>
#include <cmath>
#include <algorithm>
#include <complex>
#include <math.h>
#include <chrono>

// Struct that defines the operation that a < b for vectors a,b if a has fewer elements than b
struct {
	bool operator()(std::vector<std::complex<double>> a, std::vector<std::complex<double>> b) const { return a.size() < b.size(); }
} customLess;

// Returns the 2 norm of a vector
template <typename T>
double two_norm(std::vector<std::complex<T>>& f);

// Rescales the vectors of the DFT to enforce isometry
template <typename T>
void DFT_rescale(std::vector<std::complex<T>>& f);

// The isometry version of the FFT
template <typename T>
std::vector<std::complex<T>> unit_FFT(std::vector<std::complex<T>>& f, bool invert);

// Unscaled FFT
template <typename T>
std::vector<std::complex<T>> FFT(std::vector<std::complex<T>> f, bool invert);


// Iterative DFT method
template <typename T>
std::vector<std::complex<T>> DFT(std::vector<std::complex<T>> f, bool invert);


// displays the elements of a vector
template <typename T>
void display_vec(const std::vector<T> & vec);

// gets the lengths of vectors in a table of vectors
template <typename T>
std::vector<size_t> get_lengths(std::vector<T> vec);

// calculates the norms of a table of vectors
template <typename T>
std::vector<double> gen_norms(const std::vector<std::vector<T>>& vecs);

// generates a vector of random complex doubles given size n and 
// a max/min value
std::vector<std::complex<double>> gen_vec(size_t n, double min, double max);

// random double generator
double fRand(double fMin, double fMax);

// gereates a table of random vectors
std::vector<std::vector<std::complex<double>>> gen_vecvec(double min, double max, size_t num_vecs);

// computes the DFT of a table of vectors
std::vector<std::vector<std::complex<double>>> gen_vecvecFFT(double min, double max, size_t num_vecs);

// displays a complex vector in x+iy notation
void display_complexvec(std::vector<std::complex<double>>& vec);

// displays a complex vector vector in x+iy notation
void display_complexvecvec(std::vector<std::vector<std::complex<double>>>& vec);

// creates the difference vector vector table of y = abs(x - IDFT(DFT(x))
std::vector<double> inf_norms(std::vector<std::vector<std::complex<double>>> vecvec1, 
	std::vector<std::vector<std::complex<double>>> vecvec2);

// finds the eigenvalus of a circular matrix
std::vector<std::complex<double>> circ_eigen(std::vector<std::vector<std::complex<double>>> M, bool invert);

// Evaluates a complex polynomial via Horner's rule
void horner(std::vector<std::complex<double>> coeff, std::complex<double> z_0);

template <typename T>
double two_norm(std::vector<std::complex<T>> &f)
{
	std::complex<T> sum = 0;
	for (size_t i = 0; i < f.size(); i++)
	{
		sum += f[i] * std::conj(f[i]);
	}
	return sqrt(sum).real();
}

template <typename T>
void DFT_rescale(std::vector<std::complex<T>>& f)
{
	for (size_t i = 0; i < f.size(); i++)
	{
		f[i] *= 1 / sqrt(f.size());
	}
}

template <typename T>
void rescale(std::vector<std::complex<T>>& f)
{
	for (size_t i = 0; i < f.size(); i++)
	{
		f[i] /= sqrt(f.size());
	}
}

template <typename T>
std::vector<std::complex<T>> scale_FFT(std::vector<std::complex<T>>& f, bool invert)
{
	std::vector<std::complex<T>> y(FFT(f, invert));
	DFT_rescale(y);
	rescale(y);
	return y;
}

template <typename T>
std::vector<std::complex<T>> unit_FFT(std::vector<std::complex<T>> & f, bool invert)
{
	std::vector<std::complex<T>> y(FFT(f, invert));
	DFT_rescale(y);
	return y;
}

template <typename T>
std::vector<std::complex<T>> FFT(std::vector<std::complex<T>> f, bool invert)
{
	double pi = 2 * acos(0.0);
	size_t n = f.size();
	if (n == 1)
	{
		return f;
	}
	std::vector<std::complex<T>> f_even(n / 2);
	std::vector<std::complex<T>> f_odd(n / 2);
	for (size_t i = 0; i < n / 2; i++)
	{
		f_even[i] = f[2 * i];
		f_odd[i] = f[2 * i + 1];
	}
	std::vector<std::complex<T>> y_even = FFT(f_even, invert);
	std::vector<std::complex<T>> y_odd = FFT(f_odd, invert);
	std::vector<std::complex<T>> y(n);
	double theta = - 2 * pi / n;
	if (invert)
	{
		theta *= -1;
	}
	std::complex<double> omega = std::polar(1.0, theta);
	for (size_t i = 0; i < n / 2; i++)
	{
		y[i] = y_even[i] + pow(omega, i) * y_odd[i];
		y[i + n / 2] = y_even[i] - pow(omega, i) * y_odd[i];
	}
	return y;
}

template <typename T>
std::vector<std::complex<T>> DFT(std::vector<std::complex<T>> f, bool invert)
{
	size_t n = f.size();
	double pi = 2 * acos(0.0);
	std::vector<std::complex<T>> y(n);
	double theta = -2.0 * pi / n;
	if (invert)
	{
		theta *= -1;
	}
	std::complex<double> omega = std::polar(1.0, theta);
	for (size_t i = 0; i < n; i++)
	{
		std::complex<double> sum = { 0,0 };
		for (size_t j = 0; j < n; j++)
		{
			sum += f[j] * pow(pow(omega, j), i);
		}
		y[i] = sum;
	}
	DFT_rescale(y);
	return y;
}


template <typename T>
void display_vecvec(const std::vector<std::vector<T>>& vecs)
{
	for (size_t i = 0; i < vecs.size(); i++)
	{
		for (size_t j = 0; j < vecs[i].size(); j++)
		{
			std::cout << vecs[i][j] << " ";
		}
		std::cout << std::endl;
	}
}

template <typename T>
void display_vec(const std::vector<T>& vec)
{
	for (size_t i = 0; i < vec.size(); i++)
	{
		std::cout << vec[i] << std::endl;
	}
	std::cout << std::endl;
}

template <typename T>
std::vector<size_t> get_lengths(std::vector<T> vec)
{
	std::vector<size_t> vec_lengths;
	for (size_t i = 0; i < vec.size(); i++)
	{
		vec_lengths.push_back(vec[i].size());
	}
	return vec_lengths;
}

template <typename T>
std::vector<double> gen_norms(const std::vector<std::vector<T>>& vecs)
{
	std::vector<double> norms;
	std::complex<double> sum = 0.0;
	for (size_t i = 0; i < vecs.size(); i++)
	{
		for (size_t j = 0; j < vecs[i].size(); j++)
		{
			sum += vecs[i][j] * std::conj(vecs[i][j]);
		}
		norms.push_back(sqrt(sum).real());
		sum = 0.0;
	}
	return norms;
}

std::vector<std::complex<double>> gen_vec(size_t n, double min, double max)
{
	std::vector<std::complex<double>> vec(n);
	for (size_t i = 0; i < n; i++)
	{
		double re = fRand(min, max);
		double im = fRand(min, max);
		std::complex<double> temp(re, im);
		vec[i] = temp;
	}
	return vec;
}

double fRand(double fMin, double fMax)
{
	double f = (double)rand() / RAND_MAX;
	return fMin + f * (fMax - fMin);
}

std::vector<std::vector<std::complex<double>>> gen_vecvec(double min, double max, size_t num_vecs)
{
	std::vector<std::vector<std::complex<double>>> vecs;
	for (size_t i = 0; i < num_vecs; i++)
	{
		size_t n = rand() % 100 + 1;
		std::vector<std::complex<double>> vec(gen_vec(n, min, max));
		vecs.push_back(vec);
		vec.clear();
	}
	std::sort(vecs.begin(), vecs.end(), customLess);
	return vecs;
}

std::vector<std::vector<std::complex<double>>> gen_vecvecFFT(double min, double max, size_t num_vecs)
{
	std::vector<std::vector<std::complex<double>>> vecs;
	for (size_t i = 0; i < num_vecs; i++)
	{
		size_t n = pow(2, rand() % 10 + 1);
		std::vector<std::complex<double>> vec(gen_vec(n, min, max));
		vecs.push_back(vec);
		vec.clear();
	}
	std::sort(vecs.begin(), vecs.end(), customLess);
	return vecs;
}

std::vector<std::vector<std::complex<double>>> DFT_vecvec(std::vector<std::vector<std::complex<double>>> vecvec, bool invert)
{
	std::vector<std::complex<double>> tempvec;
	std::vector<std::vector<std::complex<double>>> DFTvecvec;
	for (size_t i = 0; i < vecvec.size(); i++)
	{
		for (size_t j = 0; j < vecvec[i].size(); j++)
		{
			tempvec.push_back(vecvec[i][j]);
		}
		std::vector<std::complex<double>> tempDFTvec(DFT(tempvec, invert));
		DFTvecvec.push_back(tempDFTvec);
		tempvec.clear();
		tempDFTvec.clear();
	}
	return DFTvecvec;
}

std::vector<std::vector<std::complex<double>>> FFT_vecvec(std::vector<std::vector<std::complex<double>>> vecvec, bool invert)
{
	std::vector<std::complex<double>> tempvec;
	std::vector<std::vector<std::complex<double>>> DFTvecvec;
	for (size_t i = 0; i < vecvec.size(); i++)
	{
		for (size_t j = 0; j < vecvec[i].size(); j++)
		{
			tempvec.push_back(vecvec[i][j]);
		}
		std::vector<std::complex<double>> tempDFTvec(unit_FFT(tempvec, invert));
		DFTvecvec.push_back(tempDFTvec);
		tempvec.clear();
		tempDFTvec.clear();
	}
	return DFTvecvec;
}

std::vector<double> pointwise_error(std::vector<double> p, std::vector<double> y)
{
	std::vector<double> error;
	error.resize(p.size());
	for (size_t i = 0; i < p.size(); i++)
	{
		error.at(i) = abs(p.at(i) - y.at(i));
	}
	return error;
}

double infinity_norm(std::vector<double> p, std::vector<double> y)
{
	std::vector<double> error = pointwise_error(p, y);
	return *max_element(error.begin(), error.end());
}

double complex_inf_norm(std::vector<std::complex<double>> p, std::vector<std::complex<double>> y)
{
	std::vector<std::complex<double>> diffs(p.size());
	std::vector<double> normdiffs(p.size());
	for (size_t i = 0; i < p.size(); i++)
	{
		diffs[i] = p[i] - y[i];
		normdiffs[i] = norm(diffs[i]);
	}
	return *max_element(normdiffs.begin(), normdiffs.end());
}


void display_complexvec(std::vector<std::complex<double>>& vec)
{
	std::cout << "(";
	for (size_t i = 0; i < vec.size(); i++)
	{
		std::cout << vec[i].real() << "+" << vec[i].imag() << "i";
		if (i != vec.size() - 1)
		{
			std::cout << ", ";
		}
	}
	std::cout << ")";
}

void display_complexvecvec(std::vector<std::vector<std::complex<double>>>& vec)
{
	
	std::vector<std::complex<double>> temp;
	for (size_t i = 0; i < vec.size(); i++)
	{
		for (size_t j = 0; j < vec[i].size(); j++)
		{
			temp.push_back(vec[i][j]);
		}
		display_complexvec(temp);
		std::cout << std::endl;
		temp.clear();
	}
}

std::vector<double> inf_norms(std::vector<std::vector<std::complex<double>>> vecvec1,
	std::vector<std::vector<std::complex<double>>> vecvec2)
{
	std::vector<double> inf_norm_vec;

	std::vector<std::complex<double>> vec1;
	std::vector<std::complex<double>> vec2;
	for (size_t i = 0; i < vecvec1.size(); i++)
	{
		for (size_t j = 0; j < vecvec1[i].size(); j++)
		{
			vec1.push_back(vecvec1[i][j]);
			vec2.push_back(vecvec2[i][j]);
		}
		inf_norm_vec.push_back(complex_inf_norm(vec1, vec2));
	}
	return inf_norm_vec;
}


std::vector<std::complex<double>> circ_eigen(std::vector<std::vector<std::complex<double>>> M, bool invert)
{
	std::vector<std::complex<double>> vec;
	for (size_t i = 0; i < M.size(); i++)
	{
		vec.push_back(M[i][0]);
	}
	return DFT(vec, invert);
}


std::vector<std::complex<double>> circ_lin_sys(std::vector<std::vector<std::complex<double>>> M,
	std::vector<std::complex<double>> b)
{
	bool invert = false;
	/*if (b.size() != M[0].size() || b.size() != M.size())
	{

	}*/
	std::vector<std::complex<double>> c;
	for (size_t i = 0; i < M.size(); i++)
	{
		c.push_back(M[0][i]);
	}
	std::vector<std::complex<double>> bFFT(unit_FFT(b, invert));
	std::vector<std::complex<double>> cFFT(unit_FFT(c, invert));
	std::vector<std::complex<double>> temp(b.size());
	for (size_t i = 0; i < bFFT.size(); i++)
	{
		temp[i] = b[i] / c[i];
	}
	invert = true;
	return unit_FFT(temp, invert);
}

void horner(std::vector<std::complex<double>> coeff, std::complex<double> z_0)
{
	std::complex<double> result = 0;
	std::complex<double> j = (0, 1);
	for (size_t i = 0; i < coeff.size(); i++)
	{
		result += coeff[i] * exp(j * z_0 * static_cast<std::complex<double>>(i));
	}
	std::cout << result;
}

#endif