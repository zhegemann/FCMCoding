// FCMHW3.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <fstream>
#include "hw3.h"
#include <ctime>


using namespace std;

int main()
{
	srand(time(NULL));
	Pivot pivot = Pivot::Complete;
	Norm norm = Norm::Frobenius;
	double fMin = -100;
	double fMax = 100;

	
	for (size_t i = 2; i < 40; i++)
	{
		vector<vector<double>> A;
		vector<double> temp(i);
		vector<double> b(i);
		for (size_t j = 0; j < i; j++)
		{
			
			for (size_t k = 0; k < i; k++)
			{
				temp[k] =  fMin + ((double)rand() / (RAND_MAX)) * (fMax - fMin);
				b[k] = fMin + ((double)rand() / (RAND_MAX)) * (fMax - fMin);
			}
			A.push_back(temp);
		}
		vector<vector<double>> B(copyMatrix(A));
		size_t n = B.size();
		vector<size_t> P(n);
		vector<size_t> Q(n);
		//display_vec(matrixMult(A, x));
		
		///*cout << "original matrix: " << endl;
		//display_vecvec(b);
		//cout << endl << endl;
		//cout << "factored matrix: " << endl;*/
		LUfactor(B, n, pivot, P, Q);
		vector<double> x(evaluateLU(B, b, P, Q, pivot));
		//display_vec(b);
		double res = residual(x, matrixMult(A, x), norm);

		cout << i << " " <<  log(res) << endl;
		res = 0;
	}

	//size_t n = B.size();
	//vector<size_t> P(n);
	//vector<size_t> Q(n);
	//cout << "Original Matrix: " << endl;
	//display_vecvec(B);
	//cout << endl << endl;
	//cout << "Factored Matrix: " << endl;
	//LUfactor(B, n, pivot, P, Q);
	//display_vecvec(B);
	//double growth = growthFactor(A, B, norm);
	//
	//

	//cout << endl; 

	//cout << growth << endl;

	//display_vec(P);
	//cout << endl;
	//display_vec(Q);

	


	/*vector<double> b = { 30, 98, 157, 159 };
	
	display_vec(b);
	vector<double> x(evaluateLU(B, b, P, Q, pivot));
	display_vec(x);*/
	
	
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
