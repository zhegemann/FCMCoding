#pragma once
#ifndef MY_FUNCTION_H
#define MY_FUNCTION_H
#include <vector>
#include <valarray>
#include <cmath>
#include <algorithm>
#include <complex>
#include <math.h>
#include <chrono>

using namespace std;

enum class Pivot
{
	None,
	Partial,
	Complete
};

enum class Abs
{
	None,
	AbsVal
};

enum class Norm
{
	One,
	Infinity,
	Frobenius
};


/* A routine which takes in a square nxn matrix A and returns 
a lower triangular matrix L and upper triangular matrix U stored
within the original matrix A*/
template <typename T>
void LUfactor(vector<vector<T>> & A, size_t n, Pivot type, vector<size_t> & P, vector<size_t> & Q);

// A routine which copies the matrix A
template <typename T>
vector<vector<T>> copyMatrix(vector<vector<T>> & A);

// displays the elements of a vector
template <typename T>
void display_vec(const vector<T>& vec);

// display the elements of a matrix
template <typename T>
void display_vecvec(const vector<vector<T>>& vecs);

// Evaluates the lower L matrix stored in the in-place LU factorization
template <typename T>
vector<T> forwardSub(vector<vector<T>>& A, vector<T> b); 

// Evaluates the upper U matrix stored in the in-place LU factorization
template <typename T> 
vector<T> backwardSub(vector<vector<T>>& A, vector<T> b);

// Evaluates an LU factored matrix
template <typename T>
vector<T> evaluateLU(vector<vector<T>>& A, vector<T> b, vector<size_t> P, vector<size_t> Q, Pivot pivot);

// Finds the largest magnitude element of a column of a matrix below the (i,i) entry
template <typename T>
size_t findMaxCol(vector<vector<T>>& A, size_t column);

// Swaps two rows of a matrix
template <typename T>
void swapRows(vector<vector<T>>& A, size_t row1, size_t row2);

// Finds the largest magnitude element of the active part of a matrix being LU factored
template <typename T>
void findMaxActiveMatrix(vector<vector<T>>& A, size_t i, vector<size_t> & P, vector<size_t> & Q);

// Swaps two columns of a matrix
template <typename T>
void swapCol(vector<vector<T>>& A, size_t col1, size_t col2);

// Permutes a vector b given a permutation vector P
template <typename T>
void permutevec(vector<T> & b, vector<size_t> P);

// Takes the inverse permutation and applies it to vector x given permutation vector Q
template <typename T>
void invertPermute(vector<T>& x, vector<size_t> Q);

// Multiplies out matrices L and U within the in-place matrix parameter A. Returns M, the multiplied  matrix
template <typename T>
vector<vector<T>> multiplyLU(vector<vector<T>> LU, Abs absVal);

// The infinity norm of a matrix
template <typename T>
T infNormMatrix(vector<vector<T>> M);

// The one norm for a matrix
template <typename T>
T oneNormMatrix(vector<vector<T>> M);

// The Frobenious norm of a matrix
template <typename T>
T froNormMatrix(vector<vector<T>> M);

// The infinity norm of a vector
template <typename T>
T infNorm(vector<T> x);

// The one norm of a vector
template <typename T>
T oneNorm(vector<T> x);

// Computes the factorization accuracy
template <typename T>
T factAccuracy(vector<vector<T>> LU, vector<vector<T>> A, vector<size_t> P, vector<size_t> Q, Norm norm, Pivot pivot);

// Permutes a matrix A given permutation vectors P and Q
template <typename T>
void permuateMatrix(vector<vector<T>> A, vector<size_t> P, vector<size_t> Q, Pivot pivot);

// Solutaion accuracy
template <typename T>
T solAccuracy(vector<T> x, vector<T> xbar, Norm norm);

// Simple matrix multiplication
template <typename T>
vector<T> matrixMult(vector<vector<T>> A, vector<T> x);

// Growth factor
template <typename T>
T growthFactor(vector<vector<T>> A, vector<vector<T>> B, Norm norm);

// Residual
template <typename T>
T residual(vector<T> b, vector<T> Ax, Norm norm);

template <typename T>
void LUfactor(vector<vector<T>> & A, size_t n, Pivot pivot, vector<size_t> & P, vector<size_t> & Q)
{
	const double TOOSMALL = 0.00001;
	if (pivot == Pivot::None)
	{
		for (size_t k = 0; k < n; k++)
		{
			if (abs(A[k][k]) < TOOSMALL)
			{
				cout << "Element k,k of A is too small. Exiting.";
				exit(0);
			}
		}
		for (size_t i = 0; i < n; i++)
		{
			for (size_t j = i + 1; j < n; j++)
			{
				A[j][i] /= A[i][i];
			}
			for (size_t k = i + 1; k < n; k++)
			{
				for (size_t m = i + 1; m < n; m++)
				{
					A[k][m] -= A[k][i] * A[i][m];
				}
			}
		}

	}
	if (pivot == Pivot::Partial)
	{
		if (P.size() != A.size())
		{
			cout << "Invalid dimension of permutation vector. Terminating.";
			exit(0);
		}
		for (size_t i = 0; i < n; i++)
		{
			P[i] = findMaxCol(A, i);
			swapRows(A, i, P[i]);
			if (abs(A[i][i]) < TOOSMALL)
			{
				cout << "No suitable pivot element available in our matrix. Terminating.";
				exit(0);
			}
			for (size_t j = i + 1; j < n; j++)
			{
				A[j][i] /= A[i][i];
			}
			for (size_t k = i + 1; k < n; k++)
			{
				for (size_t m = i + 1; m < n; m++)
				{
					A[k][m] -= A[k][i] * A[i][m];
				}
			}
		}

	}
	if (pivot == Pivot::Complete)
	{
		for (size_t i = 0; i < n; i++)
		{
			findMaxActiveMatrix(A, i, P, Q);
			swapRows(A, i, P[i]);
			swapCol(A, i, Q[i]);
			if (abs(A[i][i]) < TOOSMALL)
			{
				cout << "No suitable pivot element available in our matrix. Terminating.";
				exit(0);
			}
			for (size_t j = i + 1; j < n; j++)
			{
				A[j][i] /= A[i][i];
			}
			for (size_t k = i + 1; k < n; k++)
			{
				for (size_t m = i + 1; m < n; m++)
				{
					A[k][m] -= A[k][i] * A[i][m];
				}
			}
		}

	}

}

template <typename T>
vector<vector<T>> copyMatrix(vector<vector<T>> & A)
{
	if (A.size() == 0)
	{
		cout << "Empty matrix, terminating program. ";
		exit(0);
	}
	vector<vector<T>> B;
	B.resize(A.size());
	for (size_t i = 0; i < A.size(); i++)
	{
		B[i] = A[i];
	}
	return B;
}

template <typename T>
void display_vec(const std::vector<T>& vec)
{
	for (size_t i = 0; i < vec.size(); i++)
	{
		cout << vec[i] << endl;
	}
	cout << std::endl;
}

template <typename T>
void display_vecvec(const vector<vector<T>>& vecs)
{
	for (size_t i = 0; i < vecs.size(); i++)
	{
		for (size_t j = 0; j < vecs[i].size(); j++)
		{
			cout << vecs[i][j] << " ";
		}
		cout << std::endl;
	}
}

template <typename T>
vector<T> forwardSub(vector<vector<T>>& A, vector<T> b)
{
	if (A.size() != b.size())
	{
		cout << "Dimensions of A and b do not match for forward substitution.";
		exit(0);
	}
	vector<T> x(A.size());
	for (size_t i = 0; i < A.size(); i++)
	{
		T dummy = 0;
		for (size_t j = 0; j < i; j++)
		{
			dummy += A[i][j] * x[j];
		}
		x[i] = b[i] - dummy;
	}
	return x;
}

template <typename T>
vector<T> backwardSub(vector<vector<T>>& A, vector<T> b)
{
	vector<T> x(A.size());
	for (size_t i = A.size(); i > 0; i--)
	{
		T dummy = 0;
		for (size_t j = i; j < A.size(); j++)
		{
			dummy += A[i-1][j] * x[j];
		}
		x[i-1] = (b[i-1] - dummy) / A[i-1][i-1];
	}
	return x;
}

template <typename T>
vector<T> evaluateLU(vector<vector<T>>& A, vector<T> b, vector<size_t> P, vector<size_t> Q, Pivot pivot)
{
	if (pivot == Pivot::Partial || pivot == Pivot::Complete)
	{
		permutevec(b, P);
	}
	vector<T> y(forwardSub(A, b));
	vector<T> x(backwardSub(A, y));
	if (pivot == Pivot::Complete)
	{
		invertPermute(x, Q);
	}
	return x;
}

template <typename T>
size_t findMaxCol(vector<vector<T>>& A, size_t i)
{
	double max = 0;
	size_t index = 0;
	// search the ith column for pivoting candidate
	for (size_t j = i; j < A.size(); j++)
	{
		if (abs(A[j][i]) > max)
		{
			max = abs(A[j][i]);
			index = j;
		}
	}
	return index;
}

template <typename T>
void swapRows(vector<vector<T>>& A, size_t row1, size_t row2)
{
	swap(A[row1], A[row2]);
}

template <typename T>
void findMaxActiveMatrix(vector<vector<T>>& A, size_t i, vector<size_t> & P, vector<size_t> & Q)
{
	double max = 0;
	for (size_t j = i; j < A.size(); j++)
	{
		for (size_t k = i; k < A.size(); k++)
		{
			if (abs(A[j][k]) > max)
			{
				max = abs(A[j][k]);
				P[i] = j;
				Q[i] = k;
			}
		}
	}
}

template <typename T>
void swapCol(vector<vector<T>>& A, size_t col1, size_t col2)
{
	vector<T> temp(A.size());
	for (size_t i = 0; i < A.size(); i++)
	{
		temp[i] = A[i][col1];
		A[i][col1] = A[i][col2];
		A[i][col2] = temp[i];
	}
}

template <typename T>
void permutevec(vector<T> & b, vector<size_t> P)
{
	for (size_t i = 0; i < b.size(); i++)
	{
		swap(b[i], b[P[i]]);
	}
}

template <typename T>
void invertPermute(vector<T>& x, vector<size_t> Q)
{
	size_t n = Q.size() - 1;
	for (size_t i = 0; i < x.size(); i++)
	{
		swap(x[n - i], x[Q[n - i]]);
	}
}

template <typename T>
vector<vector<T>> multiplyLU(vector<vector<T>> LU, Abs absVal)
{
		size_t n = LU.size();
	vector<vector<T>> M(n);
	if (absVal == Abs::AbsVal)
	{
		for (size_t i = 0; i < n; i++)
		{
			vector<T> temp(n);
			for (size_t j = 0; j < n; j++)
			{
				T sum = 0;
				for (size_t k = 0; k < n; k++)
				{
					if (k > j)
					{
						break;
					}
					if (k == i)
					{
						sum += abs(LU[k][j]);
						break;
					}
					sum += abs(LU[i][k]) * abs(LU[k][j]);
				}
				temp[j] = sum;
			}
			M[i] = temp;
		}
	}
	else
	{
		for (size_t i = 0; i < n; i++)
		{
			vector<T> temp(n);
			for (size_t j = 0; j < n; j++)
			{
				T sum = 0;
				for (size_t k = 0; k < n; k++)
				{
					if (k > j)
					{
						break;
					}
					if (k == i)
					{
						sum += LU[k][j];
						break;
					}
					sum += LU[i][k] * LU[k][j];
				}
				temp[j] = sum;
			}
			M[i] = temp;
		}
	}

	
	return M;
}

template <typename T>
T infNormMatrix(vector<vector<T>> M)
{
	double norm = 0;
	for (size_t i = 0; i < M.size(); i++)
	{
		double temp = 0;
		for (size_t j = 0; j < M[i].size(); j++)
		{
			temp += abs(M[i][j]);
		}
		if (temp > norm)
		{
			norm = temp;
		}
	}
	return norm;
}

template <typename T>
T oneNormMatrix(vector<vector<T>> M)
{
	T norm = 0;
	for (size_t i = 0; i < M.size(); i++)
	{
		T temp = 0;
		for (size_t j = 0; j < M[i].size(); j++)
		{
			temp += abs(M[j][i]);
		}
		if (temp > norm)
		{
			norm = temp;
		}
	}
	return norm;
}

template <typename T>
T froNormMatrix(vector<vector<T>> M)
{
	T norm = 0;
	for (size_t i = 0; i < M.size(); i++)
	{
		for (size_t j = 0; j < M.size(); j++)
		{
			norm += pow(abs(M[i][j]), 2);
		}
	}
	return sqrt(norm);
}

template <typename T>
T infNorm(vector<T> x)
{
	T norm = 0;
	for (size_t i = 0; i < x.size(); i++)
	{
		if (abs(x[i] > norm))
		{
			norm = abs(x[i]);
		}
	}
	return norm;
}

template <typename T>
T oneNorm(vector<T> x)
{
	T norm = 0;
	for (size_t i = 0; i < x.size(); i++)
	{
		norm += abs(x[i]);
	}
	return norm;
}

template <typename T>
T factAccuracy(vector<vector<T>> LU, vector<vector<T>> A, vector<size_t> P, vector<size_t> Q, Norm norm, Pivot pivot)
{
	T accuracy = 0;
	if (norm == Norm::One)
	{
		vector<vector<T>> differenceMatrix{ LU };
		permuateMatrix(A, P, Q, pivot);
		for (size_t i = 0; i < LU.size(); i++)
		{
			for (size_t j = 0; j < LU.size(); j++)
			{
				differenceMatrix[i][j] -= A[i][j];
			}
		}
		accuracy = oneNormMatrix(differenceMatrix) / oneNormMatrix(A);
	}
	if (norm == Norm::Infinity)
	{
		vector<vector<T>> differenceMatrix{ LU };
		permuateMatrix(A, P, Q, pivot);
		for (size_t i = 0; i < LU.size(); i++)
		{
			for (size_t j = 0; j < LU.size(); j++)
			{
				differenceMatrix[i][j] -= A[i][j];
			}
		}
		accuracy = infNormMatrix(differenceMatrix) / infNormMatrix(A);
	}
	if (norm == Norm::Frobenius)
	{
		vector<vector<T>> differenceMatrix{ LU };
		permuateMatrix(A, P, Q, pivot);
		for (size_t i = 0; i < LU.size(); i++)
		{
			for (size_t j = 0; j < LU.size(); j++)
			{
				differenceMatrix[i][j] -= A[i][j];
			}
		}
		accuracy = froNormMatrix(differenceMatrix) / froNormMatrix(A);
	}
	return accuracy;
}

template <typename T>
void permuateMatrix(vector<vector<T>> A, vector<size_t> P, vector<size_t> Q, Pivot pivot)
{
	if (pivot == Pivot::Partial)
	{
		for (size_t i = 0; i < A.size(); i++)
		{
			swapRows(A, i, P[i]);
		}
	}
	if (pivot == Pivot::Complete)
	{
		for (size_t i = 0; i < A.size(); i++)
		{
			swapRows(A, i, P[i]);
			swapCol(A, i, Q[i]);
		}
	}
}

template <typename T>
T solAccuracy(vector<T> x, vector<T> xbar, Norm norm)
{
	T accuracy = 0;
	if (norm == Norm::Infinity)
	{
		vector<T> xdiff{ x };
		for (size_t i = 0; i < x.size(); i++)
		{
			xdiff[i] -= xbar[i];
		}
		accuracy = infNorm(xdiff) / infNorm(x);
	}
	if (norm == Norm::One)
	{
		T accuracy = 0;
		if (norm == Norm::Infinity)
		{
			vector<T> xdiff{ x };
			for (size_t i = 0; i < x.size(); i++)
			{
				xdiff[i] -= xbar[i];
			}
			accuracy = oneNorm(xdiff) / oneNorm(x);
		}
	}
	
	return accuracy;
}

template <typename T>
vector<T> matrixMult(vector<vector<T>> A, vector<T> x)
{
	vector<T> solution(x.size());
	for (size_t i = 0; i <A.size(); i++)
	{
		for (size_t j = 0; j < A.size(); j++)
		{
			solution[i] += (A[i][j] * x[j]);
		}
	}
	return solution;
}

template <typename T>
T growthFactor(vector<vector<T>> originalA, vector<vector<T>> LUofA, Norm norm)
{
	vector<vector<T>> absLU(multiplyLU(LUofA, Abs::AbsVal));
	if (norm == Norm::Frobenius)
	{
		return froNormMatrix(absLU) / froNormMatrix(originalA);
	}
	else if (norm == Norm::Infinity)
	{
		return infNormMatrix(absLU) / infNormMatrix(originalA);
	}
	else
	{
		return oneNormMatrix(absLU) / oneNormMatrix(originalA);
	}
}

template <typename T>
T residual(vector<T> b, vector<T> Ax, Norm norm)
{
	vector<T> difference;
	for (size_t i = 0; i < b.size(); i++)
	{
		difference.push_back(b[i] - Ax[i]);
	}
	if (norm == Norm::One)
	{
		return oneNorm(difference) / oneNorm(b);
	}
	else
	{
		return infNorm(difference) / infNorm(b);
	}
}



#endif