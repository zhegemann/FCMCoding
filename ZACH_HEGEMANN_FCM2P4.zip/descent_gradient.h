#pragma once
#ifndef HEADER_H
#define HEADER_H
#include <vector>
#include <valarray>
#include <cmath>
#include <algorithm>
#include <complex>
#include <math.h>
#include <chrono>
using namespace std;

enum class Precon
{
	none,
	jacobi,
	SGS,
	Block,
	Tridiag
	
};


// Copies a matrix of double precision to single precision
vector<vector<float>> copyDMatToFMat(vector<vector<double>>& A); 

// Copies a vector of double precision to single precision
vector<float> copyDVecToFVec(vector<double> &v);

// Matrix Vector product of banded symmetric positive definite matrix A and vector r
// The matrix, A, has k sub-diagonals and super-diagonals
template <typename T>
vector<T> symmArMult(vector<vector<T>> A, vector<T> r, size_t k, size_t n);

// Stores the diagonal and offdiagonals of a banded symmetric positive definite matrix A to save storage
template <typename T>
vector<vector<T>> gatherOffDiag(vector<vector<T>> A, size_t k);

// Performs steepest descent and preconditioned steepest descent depending on our flag "precon"
template <typename T>
vector<T> SD(vector<vector<T>> H, vector<T> b, vector<T> x0, size_t k, vector<T> soln, T tol, Precon precon);

// Returns the inner product of two vectors p, q
template <typename T>
T innerProduct(vector<T> p, vector<T> q);

// Subtracts 2 vectors from one another
template <typename T>
void vecMinus(vector<T>& v1, vector<T>& v2);

// Calculates the 2 norm
template <typename T>
double twoNorm(vector<T> v);

// The relative error between the kth step of SD and the true solution
template <typename T>
double ekRel(vector<T> xk, vector<T> x);

// The error of the residual relative to b
template <typename T>
double rbError(vector<T> rk, vector<T> b);

// Factors the tridiagonal symmetric positive matrix
template <typename T>
vector<vector<T>> triLU(vector<vector<T>> A);

// Creates the jacobi preconditioner M = diag(A)
template <typename T> 
vector<vector<T>> jacobiPrecon(vector<vector<T>> A);

// Solves the lower choleski system Ly=b
template <typename T>
vector<T> cholLower(vector<vector<T>> L, vector<T> b, size_t k);

// Solves the upper choleski system (L^T)x=y
template <typename T>
vector<T> cholUpper(vector<vector<T>> LT, vector<T> y, size_t k);

// Solves the system CC^Tx=b where CC^T is the choleski factorization of a matrix
template <typename T>
vector<T> choleskiSolve(vector<vector<T>> M, vector<T> r, size_t k);

// Given a symmetric positive definite matrix A, this method generates the Gauss
// Seidel preconditioning matrix MSGS
template <typename T>
vector<vector<T>> genMGS(vector<vector<T>> A, size_t k);

// Evaluates the factored tridiagonal symmetric positive matrix LU
template <typename T>
vector<T> evalTriLU(vector<vector<T>> LU, vector<T> b);

// Calculates Mz depending on the preconditioner
template <typename T>
vector<T> zSolve(vector<vector<T>> A, size_t k, vector<T> r, Precon precon);

// Conjugate Gradient method - with and without preconditioning
template <typename T>
vector<T> CG(vector<vector<T>> H, vector<T> b, vector<T> x0, size_t k, vector<T> soln, T tol, Precon precon);


// Computes e^k for the current step, k
template <typename T>
double ekA(vector<T> x, vector<T> xk, vector<vector<T>> A, size_t k);

// Computes the bound for SD e^k
template <typename T>
double SDekBound(T minLambda, T maxLambda, vector<T> x, vector<T> xk, vector<vector<T>> A, size_t k);

// Solves the preconditioned block system 
template <typename T>
vector<T> blockSolve(vector<vector<T>> M, vector<T> r);

// Generates the block matrix M
template <typename T>
vector<vector<T>> genBlockM(vector<vector<T>> A);

template <typename T>
vector<vector<T>> genM(vector<vector<T>> A, size_t k, Precon precon);

vector<vector<float>> copyDMatToFMat(vector<vector<double>> & A)
{
	if (A.size() == 0)
	{
		cout << "Empty matrix, terminating program. ";
		exit(0);
	}
	vector<vector<float>> B;
	B.resize(A.size());
	for (size_t i = 0; i < A.size(); i++)
	{
		for (size_t j = 0; j < A.size(); j++)
		{
			B[i][j] = static_cast<float>(A[i][j]);
		}
	}
	return B;
}

vector<float> copyDVecToFVec(vector<double>& v)
{
	vector<float> vec(v.size());
	for (size_t i = 0; i < v.size(); i++)
	{
		vec[i] = static_cast<float>(v[i]);
	}
	return vec;
}

template <typename T>
vector<T> symmArMult(vector<vector<T>> A, vector<T> r, size_t k, size_t n)
{
	vector<T> w(n);
	for (size_t i = 0; i < n; i++)
	{
		w[i] = A[0][i] * r[i];
	}
	for (size_t j = 1; j < k + 1; j++)
	{
		for (size_t l = 0; l < n - j; l++)
		{
			w[l + j] += A[j][l] * r[l];
		}
		for (size_t m = 0; m < n - j; m++)
		{
			w[m] += A[j][m] * r[m + j];
		}
	}
	return w;
}

template <typename T>
vector<vector<T>> gatherOffDiag(vector<vector<T>> A, size_t k)
{
	size_t n = A.size();
	vector<T> temp;
	vector<vector<T>> D;
	for (size_t j = 0; j < k + 1; j++)
	{
		for (size_t m = 0; m < n - j; m++)
		{
			temp.push_back(A[m][m + j]);
		}
		D.push_back(temp);
		temp.clear();
	}
	return D;
}

template <typename T>
vector<T> SD(vector<vector<T>> H, vector<T> b, vector<T> x0, size_t k, vector<T> soln, T tol, Precon precon)
{
	size_t n = H.size();
	vector<vector<T>> A(gatherOffDiag(H, k));
	vector<T> errors;
	vector<T> r;
	vector<T> x{ x0 };
	T alpha;
	unsigned steps = 0;

	if (precon == Precon::none)
	{
		vector<T> Ax0{ symmArMult(A, x0, k, n) };
		for (size_t i = 0; i < n; i++)
		{
			r.push_back(b[i] - Ax0[i]);
		}
		vector<T> v(symmArMult(A, r, k, n));
		while (ekRel(x, soln) > tol)
		{
			T bound = SDekBound(0.5, 11.1111, soln, x, A, k);
			alpha = innerProduct(r, r) / innerProduct(r, v);
			for (size_t j = 0; j < n; j++)
			{
				x[j] += r[j] * alpha;
			}
			for (size_t j = 0; j < n; j++)
			{
				r[j] -= v[j] * alpha;
			}
			v = symmArMult(A, r, k, n);
			steps++;
			errors.push_back(ekRel(x, soln));
			//cout << steps << " " << static_cast<float>(ekRel(x, soln)) << endl;
			//cout << steps << " " << log10(bound) << endl;
		} //" " << log10(ek(soln, x, A, k)) <<
		// 
	}
	else
	{
		vector<vector<T>> M(genM(H, k, precon));
//		display_vecvec(M);
		vector<T> Ax0{ symmArMult(A, x0, k, n) };
		vector<T> w;
		for (size_t i = 0; i < n; i++)
		{
			r.push_back(b[i] - Ax0[i]);
		}
		vector<T> z(zSolve(M, k, r, precon));
		while (ekRel(x, soln) > tol)
		{
			w = symmArMult(A, z, k, n);
			alpha = innerProduct(z, r) / innerProduct(z, w);
			for (size_t j = 0; j < n; j++)
			{
				x[j] += z[j] * alpha;
			}
			for (size_t j = 0; j < n; j++)
			{
				r[j] -= w[j] * alpha;
			}
			z = zSolve(M, k, r, precon);
			errors.push_back(ekRel(x, soln));
			//cout << steps << " " << ekRel(x, soln) << endl;
		/*	cout << steps << endl << endl;
			cout << ekRel(x, soln) << endl << endl;*/
			steps++;
		}
		//cout << steps;
	}
	return errors;
}

template <typename T>
T innerProduct(vector<T> p, vector<T> q)
{
	T innerP = 0;
	if (p.size() != q.size())
	{
		cout << "Inner product dimensions off. Exiting.";
		exit(0);
	}
	for (size_t i = 0; i < p.size(); i++)
	{
		innerP += p[i] * q[i];
	}
	return innerP;
}

template <typename T>
double twoNorm(vector<T> v)
{
	double sum = 0;
	for (size_t i = 0; i < v.size(); i++)
	{
		sum += v[i] * v[i];
	}
	return sqrt(sum);
}

template <typename T>
double ekRel(vector<T> xk, vector<T> x)
{
	vecMinus(xk, x);
	return twoNorm(xk) / twoNorm(x);
}

template <typename T>
double rbError(vector<T> rk, vector<T> b)
{
	return twoNorm(rk) / twoNorm(b);
}

template <typename T>
void vecMinus(vector<T>& v1, vector<T>& v2)
{
	if (v1.size() != v2.size())
	{
		cout << "Incompatible vectors to add. Exiting. ";
		exit(0);
	}
	for (size_t i = 0; i < v1.size(); i++)
	{
		v1[i] -= v2[i];
	}
}

template <typename T>
vector<vector<T>> triLU(vector<vector<T>> A)
{
	size_t k = 1;
	vector<vector<T>> M(gatherOffDiag(A, k));
	vector<T> temp{ M[1] };
	swap(M[0], M[1]);
	M.push_back(temp);
	for (size_t i = 1; i < M[1].size(); i++)
	{
		M[1][i] -= (pow(M[2][i - 1], 2) / M[1][i - 1]);
		M[2][i - 1] /= M[1][i - 1];
	}
	return M;
}

template <typename T>
vector<vector<T>> jacobiPrecon(vector<vector<T>> A)
{
	size_t n = A.size();
	vector<vector<T>> M;
	vector<T> temp;
	for (size_t i = 0; i < n; i++)
	{
		temp.push_back(A[i][i]);
		M.push_back(temp);
		temp.clear();
	}
	return M;
}

template <typename T>
vector<T> cholLower(vector<vector<T>> L, vector<T> b, size_t k)
{
	size_t n = b.size();
	if (L.size() != n)
	{
		vector<T> temp;
		for (int i = n - k; i > 1; i--)
		{
			for (int j = 1; j < i; j++)
			{
				temp.push_back(0);
			}
			L.push_back(temp);
			temp.clear();
		}
	}
	vector<T> y(b.size());
	for (size_t j = 0; j < n; j++)
	{
		T sum = 0;
		for (size_t i = 0; i < j; i++)
		{
			sum += L[j - i][i] * y[i];
		}
		y[j] = (b[j] - sum) / L[0][j];
	}
	return y;
}

template <typename T>
vector<T> cholUpper(vector<vector<T>> LT, vector<T> y, size_t k)
{
	size_t n = y.size();
	if (LT.size() != n)
	{
		vector<T> temp;
		for (int i = n - k; i > 1; i--)
		{
			for (int j = 1; j < i; j++)
			{
				temp.push_back(0);
			}
			LT.push_back(temp);
			temp.clear();
		}
	}

	vector<T> x(y.size());
	for (int k = n - 1; k >= 0; k--)
	{
		T sum = 0;
		for (size_t i = k + 1; i < n; i++)
		{
			sum += LT[i - k][k] * x[i];
		}
		x[k] = (y[k] - sum) / LT[0][k];
	}
	return x;
}

template <typename T>
vector<T> choleskiSolve(vector<vector<T>> M, vector<T> r, size_t k)
{
	vector<T> y(cholLower(M, r, k));
	vector<T> z(cholUpper(M, y, k));
	return z;
}

template <typename T>
vector<vector<T>> genMGS(vector<vector<T>> A, size_t k)
{
	vector<vector<T>> C = A;
	for (size_t i = 0; i < A.size(); i++)
	{
		C[i][i] /= sqrt(A[i][i]);
	}
	for (size_t i = 0; i < A.size(); i++)
	{
		for (size_t j = 0; j < i; j++)
		{
			C[i][j] /= sqrt(A[i][i]);
		}
		for (size_t j = i + 1; j < A.size(); j++)
		{
			C[i][j] /= sqrt(A[i][i]);
		}
	}
	
	vector<vector<T>> Cdiag(gatherOffDiag(C, k));

	return Cdiag;


}

template <typename T>
vector<T> evalTriLU(vector<vector<T>> LU, vector<T> b)
{
	size_t n = b.size();
	vector<T> y(n);
	y[0] = b[0];
	for (size_t i = 1; i < n; i++)
	{
		y[i] = b[i] - LU[2][i - 1] * y[i - 1];
	}
	vector<T> x(n);
	x[n - 1] = y[n - 1] / LU[1][n - 1];
	for (int i = n-2; i >= 0; i--)
	{
		x[i] = (y[i] - LU[0][i] * x[i + 1]) / LU[1][i];
	}
	return x;
}

template <typename T>
vector<vector<T>> genM(vector<vector<T>> A, size_t k, Precon precon)
{
	vector<vector<T>> M;
	if (precon == Precon::jacobi)
	{
		M = (jacobiPrecon(A));
	}
	if (precon == Precon::Tridiag)
	{
		M = (triLU(A));
	}
	if (precon == Precon::SGS || precon == Precon::Block)
	{
		M = (genMGS(A, k));
	}
	return M;
}

template <typename T>
vector<T> zSolve(vector<vector<T>> M, size_t k, vector<T> r, Precon precon)
{
	vector<T> z;
	if (precon == Precon::jacobi)
	{
		for (size_t i = 0; i < r.size(); i++)
		{
			z.push_back(r[i] / M[i][0]);
		}
	}
	if (precon == Precon::Tridiag)
	{
		z = evalTriLU(M, r);
	}
	if (precon == Precon::SGS || precon == Precon::Block)
	{
		z = choleskiSolve(M, r, k);
	}
	return z;
}

template <typename T>
vector<T> CG(vector<vector<T>> H, vector<T> b, vector<T> x0, size_t k, vector<T> soln, T tol, Precon precon)
{
	size_t n = H.size();
	vector<vector<T>> A(gatherOffDiag(H, k));
	vector<T> errors;
	vector<T> r;
	vector<T> x{ x0 };
	T alpha;
	T sigma_k;
	T sigma_k1;
	T mu;
	T beta;
	vector<T> v;
	vector<T> p;
	unsigned steps = 0;
	vector<T> Ax0{ symmArMult(A, x0, k, n) };
	T lambdaMax = 1.35;
	T lambdaMin = .87;
	T kappaA = lambdaMax / lambdaMin;
	for (size_t i = 0; i < n; i++)
	{
		r.push_back(b[i] - Ax0[i]);
	}
	if (precon == Precon::none)
	{
		T e0 = ekA(soln, x0, A, k);
		vector<T> temporary = x0;
		vecMinus(temporary, soln);
		T e02 = twoNorm(temporary);
		T alphaKappa = (sqrt(kappaA) - 1) / (sqrt(kappaA) + 1);
		p = r;
		while (ekRel(x, soln) > tol)
		{
			T bound = 2 * pow(alphaKappa, steps) * e02;
			sigma_k = innerProduct(r, r);
			v = symmArMult(A, p, k, n);
			mu = innerProduct(p, v);
			alpha = sigma_k / mu;
			for (size_t i = 0; i < n; i++)
			{
				x[i] += alpha * p[i];
				r[i] -= alpha * v[i];
			}
			sigma_k1 = innerProduct(r, r);
			beta = sigma_k1 / sigma_k;
			for (size_t i = 0; i < n; i++)
			{
				p[i] = r[i] + beta * p[i];
			}
			steps++;
			errors.push_back(ekRel(x, soln));
			vector<T> tempVec(n);
			for (size_t i = 0; i < n; i++)
			{
				tempVec[i] = soln[i] - x[i];
			}
			//cout << steps << " " << bound << endl;
			tempVec.clear();
		} // " " << ekA(soln, x, A, k) << 
		//" " << bound << endl <<
		// " " << twoNorm(tempVec) <<
	}
	else
	{
		vector<vector<T>> M(genM(H, k, precon));
		vector<T> z(zSolve(M, k, r, precon));
		p = z;
		while (ekRel(x, soln) > tol)
		{
			v = symmArMult(A, p, k, n);
			alpha = innerProduct(r, z) / innerProduct(p, v);
			sigma_k = innerProduct(r, z);
			for (size_t i = 0; i < n; i++)
			{
				x[i] += alpha * p[i];
				r[i] -= alpha * v[i];
			}
			z = zSolve(M, k, r, precon);
			sigma_k1 = innerProduct(r, z);
			beta = sigma_k1 / sigma_k;
			for (size_t i = 0; i < n; i++)
			{
				p[i] = z[i] + beta * p[i];
			}
			steps++;
			errors.push_back(ekRel(x, soln));
			//cout << steps << " " << ekRel(x, soln) << endl << endl;
		}

	}
	return errors;
}

template <typename T>
double ekA(vector<T> x, vector<T> xk, vector<vector<T>> A, size_t k)
{
	vecMinus(x, xk);
	size_t n = x.size();
	return innerProduct(x, symmArMult(A, x, k, n));
}

template <typename T>
double SDekBound(T minLambda, T maxLambda, vector<T> x, vector<T> xk, vector<vector<T>> A, size_t k)
{
	T kA = maxLambda / minLambda;
	T temp = (kA - 1) / (kA + 1);
	double e = ekA(x, xk, A, k);
	return temp * e;
}

template <typename T>
T fRand(T fMin, T fMax)
{
	T f = (T)rand() / RAND_MAX;
	return fMin + f * (fMax - fMin);
}

template <typename T>
vector<vector<T>> MtimesMT(vector<vector<T>> M)
{
	size_t n = M.size();
	vector<vector<T>> MMT(n);
	for (size_t i = 0; i < n; i++)
	{
		MMT[i].resize(n);
	}
	for (size_t i = 0; i < n; i++)
	{
		for (size_t j = 0; j < n; j++)
		{
			T sum = 0;
			for (size_t k = 0; k < n; k++)
			{
				sum += M[i][k] * M[j][k];
			}
			MMT[i][j] = sum;
		}
	}
	return MMT;
}

template <typename T>
vector<vector<T>> genBlockM(vector<vector<T>> A)
{
	if (A.size() % 2 != 0)
	{
		cout << "invalid A size, exiting.";
		exit(0);
	}
	vector<T> temp(2);
	vector<vector<T>> M(A.size());
	for (size_t i = 0; i < A.size() - 1; i += 2)
	{
		for (size_t j = 0; j < 2; j++)
		{
			temp[j] = A[i][i + j];
		}
		M[i] = temp;
		for (size_t j = 0; j < 2; j++)
		{
			temp[j] = A[i + 1][i + j];
		}
		M[i + 1] = temp;
	}
	return M;
}

template <typename T>
vector<T> blockSolve(vector<vector<T>> M, vector<T> r)
{

	/*vector<vector<T>> lilM(2);
	vector<T> lilr = {0, 0};
	vector<T> temp(2);
	vector<T> temp2(2);
	vector<T> z(r.size());

	for (size_t i = 0; i < r.size(); i += 2)
	{
		for (size_t j = 0; j < 2; j++)
		{
			temp[j] = M[i][j];
			temp2[j] = M[i + 1][j];
			lilr[j] = r[i + j];
		}
		lilM[0] = temp;
		lilM[1] = temp2;
		vector<vector<T>> lilChol(genMGS(lilM, 1));
		vector<T> lilz(choleskiSolve(lilChol, lilr, 1));
		for (size_t l = 0; l < lilz.size(); l++)
		{
			z[i] = lilz[l];
		}
	}*/
	//return z;
}




//
//// Adds two vectors
//template <typename T>
//void vecPlus(vector<T>& v1, vector<T>& v2);
//
//// Subtracts two vectors
//template <typename T>
//void vecMinus(vector<T>& v1, vector<T>& v2);
//
//// Scalar multiplies double alpha and vector v
//template <typename T>
//vector<T> scalarMultVec(T alpha, vector<T> v);


//template <typename T>
//void vecPlus(vector<T>& v1, vector<T>& v2)
//{
//	if (v1.size() != v2.size())
//	{
//		cout << "Incompatible vectors to add. Exiting. ";
//		exit(0);
//	}
//	for (size_t i = 0; i < v1.size(); i++)
//	{
//		v1[i] += v2[i];
//	}
//}
//
//template <typename T>
//void vecMinus(vector<T>& v1, vector<T>& v2)
//{
//	if (v1.size() != v2.size())
//	{
//		cout << "Incompatible vectors to add. Exiting. ";
//		exit(0);
//	}
//	for (size_t i = 0; i < v1.size(); i++)
//	{
//		v1[i] -= v2[i];
//	}
//}
//
//template <typename T>
//vector<T> scalarMultVec(T alpha, vector<T> v)
//{
//	vector<T> u(v.size());
//	for (size_t i = 0; i < v.size(); i++)
//	{
//		u[i] = v[i] * alpha;
//	}
//	return u;
//}


#endif
