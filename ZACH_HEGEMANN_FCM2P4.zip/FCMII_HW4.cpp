// FCMII_HW4.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "hw4.h"
#include "descent_gradient.h"

int main()
{
	srand(time(NULL));

	double fMin = -1000;
	double fMax = 1000;
	size_t n = 200;
	Precon precon = Precon::jacobi;
	size_t k = 2;
	double tol = 0.0001;
	vector<vector<double>> M(n);
	vector<double> soln(n);
	vector<double> x0(n);
	for (size_t i = 0; i < n; i++)
	{
		M[i].resize(n);
	}
	for (size_t i = 0; i < n; i++)
	{
		for (size_t j = 0; j < n; j++)
		{
			M[i][j] = fRand(fMin, fMax);
		}
		soln[i] = fRand(fMin, fMax);
		x0[i] = fRand(fMin, fMax);
	}
	vector<vector<double>> A(MtimesMT(M));
	vector<vector<double>> B(gatherOffDiag(A, k));
	vector<double> b(symmArMult(B, soln, k, n));
	vector<double> errorSD(SD(A, b, x0, k, soln, tol, precon));
	vector<double> errorCG(CG(A, b, x0, k, soln, tol, precon));
	for (size_t i = 0; i < errorCG.size(); i++)
	{
		cout << i + 1 << " " << log10(errorCG[i]) << endl;
	}
	cout << endl << endl << "^^^^^^^ end jacobi^^^^^^^^^" << endl << endl;
	precon = Precon::SGS;
	errorCG = CG(A, b, x0, k, soln, tol, precon);
	for (size_t i = 0; i < errorCG.size(); i++)
	{
		cout << i + 1 << " " << log10(errorCG[i]) << endl;
	}
	cout << endl << endl << "^^^^^^^ end SGS^^^^^^^^^" << endl << endl;
	precon = Precon::Tridiag;
	errorCG = CG(A, b, x0, k, soln, tol, precon);
	for (size_t i = 0; i < errorCG.size(); i++)
	{
		cout << i + 1 << " " << log10(errorCG[i]) << endl;
	}
	cout << endl << endl << "^^^^^^^ end tridiag^^^^^^^^^" << endl << endl;
	precon = Precon::Block;
	errorCG = CG(A, b, x0, k, soln, tol, precon);
	for (size_t i = 0; i < errorCG.size(); i++)
	{
		cout << i + 1 << " " << log10(errorCG[i]) << endl;
	}
	cout << endl << endl << "^^^^^^^ end precon^^^^^^^^^" << endl << endl;
	precon = Precon::none;
	errorCG = CG(A, b, x0, k, soln, tol, precon);
	for (size_t i = 0; i < errorCG.size(); i++)
	{
		cout << i + 1 << " " << log10(errorCG[i]) << endl;
	}
	










	/*for (size_t i = 0; i < errorSD.size(); i++)
	{
		cout << i + 1 << " " << log10(errorSD[i]) << endl;
	}
	cout << endl << endl << "^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^" << endl << endl;
	for (size_t i = 0; i < errorCG.size(); i++)
	{
		cout << i + 1 << " " << log10(errorCG[i]) << endl;
	}*/

	
								
								
								
								/*vector<vector<double>> A = { {.87, 0, 0, 0, 0, 0 , 0, 0}, {0, 1.35, 0, 0, 0, 0 , 0 , 0},
								{0, 0, 1, 0, 0, 0 , 0 , 0}, {0, 0, 0, .93333, 0, 0 , 0 , 0},
								{0, 0, 0, 0, .896547, 0 , 0 , 0}, {0, 0, 0, 0, 0, 1.02 , 0 , 0},
								{0, 0, 0, 0, 0, 0 , 1.0321 , 0}, {0, 0, 0, 0, 0, 0, 0 , 1.0876} };
	vector<double> soln = { 8, 6, 7, 5, 3, 0, 9, 1};
	vector<double> b = { 6.96, 8.1, 7, 4.66665, 2.689641, 0, 9.2889, 1.0876 };
	vector<double> x0 = { 17, -33.3333, -.275386, -9.1743, 99.8745, 3, 57.2, -31 };
	vector<double> errorSD(CG(A, b, x0, k, soln, tol, precon));*/

	/*for (size_t i = 0; i < errorSD.size(); i++)
	{
		cout << i + 1 << " " << errorSD[i] << endl;
	}*/
	/*vector<vector<double>> A = { {30, 3, 4, 0, 0, 0}, {3, 50, 7, 2, 0, 0}, {4, 7, 60, 3, 4, 0}, {0, 2, 3, 80, 1, 9},
								{0, 0, 4, 1, 30, 2}, {0, 0, 0, 9, 2, 100} };*/
	/*vector<vector<double>> A = { {30, 3, 0, 0}, {3, 50, 7, 0}, {0, 7, 60, 3}, {0, 0, 3, 80} };
	size_t n = A.size();
	vector<double> x0 = { 10, 20, 2, -5 };
	vector<double> soln = { 2, 3, 4, 5 };
	vector<double> b = { 69, 184, 276, 412 };
	vector<double> errorSD(CG(A, b, x0, k, soln, tol, precon));*/
	//display_vec(errorSD);
	

	/*vector<vector<double>> LU(triLU(A));
	display_vecvec(LU);

	vector<double> soln = { 1, 2, 3, 4 };
	vector<double> b = { 36, 124, 206, 329 };
	vector<double> x(evalTriLU(LU, b));
	display_vec(x);*/
	
	

	
	
	
	
	
	/*vector<vector<double>> B(gatherOffDiag(A, k));
	vector<double> x = { 1,	2, 3, 4, 5, 6 };
	vector<double> soln(symmArMult(B, x, k, n));
	display_vec(soln);
	vector<double> x0 = { 10, 20, 5, 3, 2, 4 };
	vector<double> b = { 48, 132, 230,  392, 178, 646 };
	vector<double> SDError(SD(A, b, x0, k, x, tol));*/
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
