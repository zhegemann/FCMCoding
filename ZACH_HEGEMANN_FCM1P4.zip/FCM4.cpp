// FCM4.cpp : Zach Hegemann
// This file computes interpolatory quadratures using the midpoint and trapezoid methods

#include <iostream>
#include <iomanip>
#include <vector>
#include <cmath>
#include "interp.h"
#include <fstream>
#include <chrono> 
using namespace std::chrono;


// Our function f
template<typename T>
T f1(T x);

template<typename T>
T f2(T x);

template<typename T>
T f3(T x);

template<typename T>
T f4(T x);

template<typename T>
T f5(T x);

int main()
{
	
	const double PI = 3.14159;
	size_t m = 2;
	double l_d= 0;
	double r_d = 3;
	float l_f = 0;
	float r_f = 3.5F;
	Mesh meshtype = Mesh::uniform;
	std::vector<double> mesh(build_mesh(meshtype, m, l_d, r_d));
	std::vector<double> midpoints(gen_midpoints(mesh));
	/*double desired_E = 0.25;
	double true_If = -0.05066059182;
	double error = abs(true_If - integrate_ctr<float>(meshtype, l_f, r_f, m, f4));
	std::ofstream myfile;
	myfile.open("error_mf4ctr.txt");
	std::cout << integrate_cmp<float>(meshtype, l_f, r_f, m, f4) << std::endl;
	for (size_t i = 0; i < 10; i++)
	{
		auto start = high_resolution_clock::now();
		while (error > desired_E)
		{
			m++;
			error = abs(true_If - integrate_ctr(meshtype, l_f, r_f, m, f4));
		}
		auto stop = high_resolution_clock::now();
		auto duration = duration_cast<milliseconds>(stop - start);
		myfile << error << " " << m << " " << duration.count() << std::endl;
		desired_E = desired_E / 2;
		std::cout << error << " " << m << " " << duration.count() << std::endl;
	}
	*/
	
}

template<typename T>
T f1(T x)
{
	return exp(x);
}

template<typename T>
T f2(T x)
{
	return exp(sin(2 *x)) * cos(2 * x);
}

template<typename T>
T f3(T x)
{
	return tanh(x);
}

template<typename T>
T f4(T x)
{
	const T PI = 3.14159;
	return x * cos(2 * PI * x);
}

template<typename T>
T f5(T x)
{
	return x + (1 / x);
}


