// FCM2.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <cmath>
#include <vector>
#include <algorithm>

const int d = 9;
const int global_n = 200;
const double left_endpoint = -2;
const double right_endpoint = 2;
std::vector<double> x_igd;

std::vector<float> x_igf;

enum class Mesh
{
	uniform,
	chev1,
	chev2
};

enum class Order
{
	increasing,
	decreasing,
	leja
};
// Swap two doubles
void swap(double* first, double* second);

// A function to implement bubble sort on an array of doubles
void bubble_sort(std::vector<double>& vec, Order order);

// Swap two floats
void swap(float* first, float* second);

// A function to implement bubble sort on an array of floats
void bubble_sort(std::vector<float>& vec, Order order);

// Generates the x_i set of data given a mesh type, input size, left endpoint, and right endpoint in double precision
std::vector<double> x_calculator(Mesh type, size_t n, double left_endpoint, double right_endpoint);

// Generates the x_i set of data given a mesh type, input size, left endpoint, and right endpoint in single precision
std::vector<float> x_calculator(Mesh type, size_t n, float left_endpoint, float right_endpoint);

// Calculate the vector y_i given a vector of x_i and a function
std::vector<double> y_calculator(std::vector<double> x_i, double (*f)(double));

// Calculate the vector y_i given a vector of x_i and a function
std::vector<float> y_calculator(std::vector<float> x_i, float (*f)(float));

// Creates the beta coefficients - uniform, chebyshev type 1, or chebyshev type 2 - given an input size, mesh type, and left endpoint in double precision
std::vector<double> base_calculator(size_t n, Mesh type, double left_endpoint);

// Creates the beta coefficients - uniform, chebyshev type 1, or chebyshev type 2 - given an input size, mesh type, and left endpoint in single precision
std::vector<float> base_calculator(size_t n, Mesh type, float left_endpoint);

// Returns the index of the largest element for a vector of doubles
size_t max_index(std::vector<double> vec);

// Returns the index of the largest element for a vector of doubles
size_t max_index(std::vector<float> vec);

// The Leja ordering for a vector of doubles
std::vector<double> leja_d(std::vector<double> x);

// The Leja ordering for a vector of floats
std::vector<float> leja_f(std::vector<float> x);

// A function that orders the values in the domain vector x. The orderings are: leja, increasing or decreasing
void x_ordering(std::vector<double> x, Order order);

// A function that orders the values in the domain vector x. The orderings are: leja, increasing or decreasing
void x_ordering(std::vector<float> x, Order order);

// Determines the pointwise error given the values for polynomial p(x) and interpolated points {y}
std::vector<double> pointwise_error(std::vector<double> p, std::vector<float> y);

// Finds the infinity norm of a vector
double infinity_norm(std::vector<double> p, std::vector<float> y);

// Function 1 as a double return type
double f1_d(double x);

// Function 1 as a float return type
float f1_f(float x);

// Function 2 as a double return type
double f2_d(double x);

// Function 2 as a float return type 
float f2_f(float x);

// Function 3 as a double return type
double f3_d(double x);

// Function 3 as a float return type
float f3_f(float x);

// Function 3 as a float return type
float d3_f(float x);

// Function 4 as a double return type
double f4_d(double x);

// Function 4 as a float return type
float f4_f(float x);

// Evaluates double precision beta coefficients as well as f(x) values for the given mesh. Outputs the beta_i and f(x_i)
void barycentric_routine1(size_t n, Mesh type, double (*f)(double), double left_endpoint, double right_endpoint);

// Evaluates single precision beta coefficients as well as f(x) values for the given mesh. Outputs the beta_i and f(x_i)
void barycentric_routine1(size_t n, Mesh type, float (*f)(float), float left_endpoint, float right_endpoint);

// Factorial function
int factorial(unsigned n);

// Displays of the function p(x) given number of points, mesh type, left and right endpoints
void display_p(size_t n, Mesh type, double left_endpoint, double right_endpoint, double (*f)(double));

// Displays function p(x) given number of points, mesh type, left and right endpoints
void display_p(size_t n, Mesh type, float left_endpoint, float right_endpoint, float (*f)(float));

// Evaluation of the punction p-hat given a number of points, mesh type, left and right endpoints
std::vector<float> evaluate_p(size_t n, Mesh type, float left_endpoint, float right_endpoint, float (*f)(float));

// Sets up a table of divided differences based on two vectors x and y in double precision
void divided_differences(size_t n, std::vector<double> x, std::vector<double> y, std::vector<double>& div_diff_table, Order ordering);

// Sets up a table of divided differences based on two vectors x and y in single precision
void divided_differences(size_t n, std::vector<float> x, std::vector<float> y, std::vector<float>& div_diff_table, Order ordering);

// A routine based on the adapted Horner's rule to display the polynomial p(x) defined in terms of the newton bases
void horner_display(size_t n, std::vector<double> div_diff_table, std::vector<double> x);

// A routine based on the adapted Horner's rule to display the polynomial p(x) defined in terms of the newton bases in single precision
void horner_display(size_t n, std::vector<float> div_diff_table, std::vector<float> x);

// A routine to evaluate the horner polynomial
std::vector<float> horner_evaluation(std::vector<float> x, size_t n, std::vector<float> div_diff_table);

// Print a vector
void print_vec(std::vector<double> vec);

// Print a vector
void print_vec(std::vector<float> vec);

double testf(double x);


float testf(float x);

int main()
{
	/* To run this code, choose your endpoints, n, and d at the top in the global constants.
	* Then once you select what mesh you want (chev1, chev2, uniform), replace the mesh type in line 162, 164, and 170
	* Note: the divided_difference function displays out the table, so it may alter output. 
	* Simply comment out the display out lines within the codes below in fuctions on line 1009 and 1047
	*/
	float left_fl_endpoint = static_cast<float>(left_endpoint);
	float right_fl_endpoint = static_cast<float>(right_endpoint);
	std::vector<double> x{ x_calculator(Mesh::chev1, global_n, left_endpoint, right_endpoint)};
	// x_ordering(x, Order::increasing);
	std::vector<float> x_float{x_calculator(Mesh::chev1, global_n, left_fl_endpoint, right_fl_endpoint)};
	// x_ordering(x_float, Order::increasing);
	std::vector<double> y{ y_calculator(x, f4_d) };
	std::vector<float> y_float{ y_calculator(x_float, f4_f) };
	std::vector<float> div_differences(global_n * global_n);
	divided_differences(global_n, x_float, y_float, div_differences, Order::decreasing);
	std::vector<float> p_hat = evaluate_p(global_n, Mesh::chev1, left_fl_endpoint, right_fl_endpoint, f4_f);

	std::cout << "Our real x values are: " << "-----------------" << std::endl;
	print_vec(x);
	
	std::cout << "Our floating point representation of the x values are: " << "-----------------" << std::endl;
	print_vec(x_float);
	
	std::cout << "Our real y values corresponding to the x_i are: -----------------------" << std::endl;
	print_vec(y);

	std::cout << "And lastly, our interpolated polynomial, p-hat, has corresponding values to the x_i: --------------" << std::endl;
	print_vec(p_hat);

	double inf_norm = infinity_norm(y, p_hat);
	std::cout << "The infinity norm is: " << inf_norm << std::endl;
	double norm;
	std::vector<double> y_abs(y.size());
	for (size_t i = 0; i < y.size(); i++)
	{
		y_abs.at(i) = abs(y.at(i));
	}
	norm = *max_element(y_abs.begin(), y_abs.end());
	std::cout << "The norm of the function f is: " << norm << std::endl;
	std::cout << "The lebesque constant is " << inf_norm / norm << std::endl;
	display_p(global_n, Mesh::uniform, static_cast<float>(left_endpoint), static_cast<float>(right_endpoint), f1_f);
	
}



void print_vec(std::vector<double> vec)
{
	for (size_t i = 0; i < vec.size(); i++)
	{
		std::cout << vec.at(i) << std::endl;
	}
}

void print_vec(std::vector<float> vec)
{
	for (size_t i = 0; i < vec.size(); i++)
	{
		std::cout << vec.at(i) << std::endl;
	}
}

void swap(double* first, double* second)
{
	double temp = *first;
	*first = *second;
	*second = temp;
}

void bubble_sort(std::vector<double>& vec, Order order)
{
	if (order == Order::increasing)
	{
		for (size_t i = 0; i < vec.size(); i++)
		{
			for (size_t j = 0; j < vec.size() - 1; j++)
			{
				if (vec.at(j) > vec.at(j + 1))
				{
					swap(&vec.at(j), &vec.at(j + 1));
				}
			}

		}
	}
	else
	{
		for (size_t i = 0; i < vec.size(); i++)
		{
			for (size_t j = 0; j < vec.size() - 1; j++)
			{
				if (vec.at(j) < vec.at(j + 1))
				{
					swap(&vec.at(j), &vec.at(j + 1));
				}
			}

		}
	}

}

void swap(float* first, float* second)
{
	float temp = *first;
	*first = *second;
	*second = temp;
}

void bubble_sort(std::vector<float>& vec, Order order)
{
	if (order == Order::increasing)
	{
		for (size_t i = 0; i < vec.size(); i++)
		{
			for (size_t j = 0; j < vec.size() - 1; j++)
			{
				if (vec.at(j) > vec.at(j + 1))
				{
					swap(&vec.at(j), &vec.at(j + 1));
				}
			}

		}
	}
	else
	{
		for (size_t i = 0; i < vec.size(); i++)
		{
			for (size_t j = 0; j < vec.size() - 1; j++)
			{
				if (vec.at(j) < vec.at(j + 1))
				{
					swap(&vec.at(j), &vec.at(j + 1));
				}
			}

		}
	}
}

std::vector<double> x_calculator(Mesh type, size_t n, double left_endpoint, double right_endpoint)
{
	std::vector<double> x(n);
	double x_i;
	if (type == Mesh::uniform)
	{
		double h = (right_endpoint - left_endpoint) / (n - 1);
		for (size_t i = 0; i < n; i++)
		{
			x_i = left_endpoint + (i * h);
			x.at(i) = x_i;
		}
	}
	else if (type == Mesh::chev1)
	{
		const double pi = 3.141592653589793;
		double angle;
		for (size_t i = 0; i < n; i++)
		{
			angle = (2 * (static_cast<double>(i) + 1)) * pi / (2 * (static_cast<double>(n) + 2));
			x_i = cos(angle);
			x_i = 0.5 * (left_endpoint + right_endpoint) + x_i * 0.5 * (left_endpoint - right_endpoint);
			x.at(i) = x_i;
		}
	}
	else
	{
		const double pi = 3.141592653589793;
		double angle;
		for (size_t i = 0; i < n; i++)
		{
			angle = static_cast<double>(i * pi) / n;
			x_i = cos(angle);
			x_i = 0.5 * (left_endpoint + right_endpoint) + x_i * 0.5 * (left_endpoint - right_endpoint);
			x.at(i) = x_i;
		}
	}
	return x;
}

std::vector<float> x_calculator(Mesh type, size_t n, float left_endpoint, float right_endpoint)
{
	std::vector<float> x(n);
	float x_i;
	if (type == Mesh::uniform)
	{
		float h = (right_endpoint - left_endpoint) / (n - 1);
		for (size_t i = 0; i < n; i++)
		{
			x_i = left_endpoint + (i * h);
			x.at(i) = x_i;
		}
	}
	else if (type == Mesh::chev1)
	{
		const float pi = 3.14159F;
		float angle;
		for (size_t i = 0; i < n; i++)
		{
			angle = (static_cast<float>(2) * (i + 1)) * pi / (static_cast<float>(2) * (n + 2));
			x_i = cos(angle);
			x_i = 0.5F * (left_endpoint + right_endpoint) + x_i * 0.5F * (left_endpoint - right_endpoint);
			x.at(i) = x_i;
		}
	}
	else
	{
		const float pi = 3.14159F;
		float angle;
		for (size_t i = 0; i < n; i++)
		{
			angle = static_cast<float>(i * pi) / n;
			x_i = cos(angle);
			x_i = 0.5F * (left_endpoint + right_endpoint) + x_i * 0.5F * (left_endpoint - right_endpoint);
			x.at(i) = x_i;
		}
	}
	return x;
}

std::vector<double> y_calculator(std::vector<double> x_i, double (*f)(double))
{
	double y_i;
	std::vector<double>y(global_n);
	for (size_t i = 0; i < global_n; i++)
	{
		y_i = f(x_i.at(i));
		y.at(i) = y_i;
	}
	return y;
}

std::vector<float> y_calculator(std::vector<float> x_i, float (*f)(float))
{
	float y_i;
	std::vector<float>y(global_n);
	for (size_t i = 0; i < global_n; i++)
	{
		y_i = f(x_i.at(i));
		y.at(i) = y_i;
	}
	return y;
}

std::vector<double> base_calculator(size_t n, Mesh type, double left_endpoint)
{
	std::vector<double> beta_coefficients(n);
	const double pi = 3.141592653589793;
	double b_i;
	double angle;
	if (type == Mesh::chev1)
	{
		for (size_t i = 0; i < n; i++)
		{
			angle = (static_cast<double>(2) * i + 1) * pi / (static_cast<double>(2) * n + 2);
			b_i = pow(-1, i) * sin(angle);
			beta_coefficients.at(i) = b_i;
		}
	}
	else if (type == Mesh::chev2)
	{
		double delta;
		for (size_t i = 0; i < n; i++)
		{
			if (i == 0 || i == (n - 1))
			{
				delta = 0.5;
				b_i = pow(-1, i) * delta;
			}
			else
			{
				delta = 1;
				b_i = pow(-1, i) * delta;
			}
			beta_coefficients.at(i) = b_i;
		}
	}
	else
	{
		b_i = n;
		beta_coefficients.at(0) = b_i;
		for (float i = 1; i < n; i++)
		{
			b_i = -1 * b_i * ((n - i) / (i + 1));
			beta_coefficients.at(static_cast<size_t>(i)) = b_i;
		}
	}
	return beta_coefficients;
}

std::vector<float> base_calculator(size_t n, Mesh type, float left_endpoint)
{
	std::vector<float> beta_coefficients(n);
	const float pi = 3.14159F;
	float b_i;
	float angle;
	if (type == Mesh::chev1)
	{
		for (size_t i = 0; i < n; i++)
		{
			angle = (static_cast<float>(2) * i + 1) * pi / (static_cast<float>(2) * n + 2);
			b_i = static_cast<float>(pow(-1, i) * sin(angle));
			beta_coefficients.at(i) = b_i;
		}
	}
	else if (type == Mesh::chev2)
	{
		float delta;
		for (size_t i = 0; i < n; i++)
		{
			if (i == 0 || i == (n - 1))
			{
				delta = 0.5;
				b_i = static_cast<float>(pow(-1, i) * delta);
			}
			else
			{
				delta = 1;
				b_i = static_cast<float>(pow(-1, i) * delta);
			}
			beta_coefficients.at(i) = b_i;
		}
	}
	else
	{
		b_i = static_cast<float>(n);
		beta_coefficients.at(0) = b_i;
		for (float i = 1; i < n; i++)
		{
			b_i = -1 * b_i * ((n - i) / (i + 1));
			beta_coefficients.at(static_cast<size_t>(i)) = b_i;
		}
	}
	return beta_coefficients;
}

size_t max_index(std::vector<double> vec)
{
	size_t max_index = 0;
	for (size_t i = 0; i < vec.size(); i++)
	{
		if (vec.at(i) > vec.at(max_index))
		{
			max_index = i;
		}
	}
	return max_index;
}

size_t max_index(std::vector<float> vec)
{
	size_t max_index = 0;
	for (size_t i = 0; i < vec.size(); i++)
	{
		if (vec.at(i) > vec.at(max_index))
		{
			max_index = i;
		}
	}
	return max_index;
}

std::vector<double> leja_d(std::vector<double> x)
{
	// A vector of the magnitudes of x
	std::vector<double> abs_x_i;
	abs_x_i.resize(x.size());
	for (size_t i = 0; i < x.size(); i++)
	{
		abs_x_i.at(i) = abs(x.at(i));
	}

	std::vector<double> leja_ordering;
	leja_ordering.resize(x.size());
	double x_max = 0;

	// Find the largest magnitude of x
	for (size_t i = 0; i < x.size(); i++)
	{
		if (abs_x_i.at(i) > x_max)
		{
			leja_ordering.at(0) = x.at(i);
		}
	}
	// Vector to hold the 0th to j-1th products to compare and find the largest
	std::vector<double> products_x_i;
	products_x_i.resize(x.size());

	// For loop to perform leja ordering
	for (size_t i = 1; i < x.size(); i++)
	{
		double running_product = 1;
		for (size_t j = 0; j < x.size(); j++)
		{
			for (size_t k = 0; k < i; k++)
			{
				running_product = running_product * abs((x.at(j) - leja_ordering.at(k)));
			}
			products_x_i.at(j) = running_product;
			running_product = 1;
		}
		leja_ordering.at(i) = x.at(max_index(products_x_i));

	}
	return leja_ordering;
}

std::vector<float> leja_f(std::vector<float> x)
{
	// A vector of the magnitudes of x
	std::vector<float> abs_x_i;
	abs_x_i.resize(x.size());
	for (size_t i = 0; i < x.size(); i++)
	{
		abs_x_i.at(i) = abs(x.at(i));
	}

	std::vector<float> leja_ordering;
	leja_ordering.resize(x.size());
	float x_max = 0;

	// Find the largest magnitude of x
	for (size_t i = 0; i < x.size(); i++)
	{
		if (abs_x_i.at(i) > x_max)
		{
			leja_ordering.at(0) = x.at(i);
		}
	}
	// Vector to hold the 0th to j-1th products to compare and find the largest
	std::vector<float> products_x_i;
	products_x_i.resize(x.size());

	// For loop to perform leja ordering
	for (size_t i = 1; i < x.size(); i++)
	{
		float running_product = 1;
		for (size_t j = 0; j < x.size(); j++)
		{
			for (size_t k = 0; k < i; k++)
			{
				running_product = running_product * abs((x.at(j) - leja_ordering.at(k)));
			}
			products_x_i.at(j) = running_product;
			running_product = 1;
		}
		leja_ordering.at(i) = x.at(max_index(products_x_i));

	}
	return leja_ordering;
}

void x_ordering(std::vector<double> x, Order order)
{
	if (order == Order::increasing)
	{
		bubble_sort(x, order);
	}
	else if (order == Order::decreasing)
	{
		bubble_sort(x, order);
	}
	else
	{
		leja_d(x);
	}
}

void x_ordering(std::vector<float> x, Order order)
{
	if (order == Order::increasing)
	{
		bubble_sort(x, order);
	}
	else if (order == Order::decreasing)
	{
		bubble_sort(x, order);
	}
	else
	{
		leja_f(x);
	}
}

std::vector<double> pointwise_error(std::vector<double> p, std::vector<float> y)
{
	std::vector<double> error;
	error.resize(p.size());
	for (size_t i = 0; i < p.size(); i++)
	{
		error.at(i) = abs(p.at(i) - y.at(i));
	}
	return error;
}

double infinity_norm(std::vector<double> p, std::vector<float> y)
{
	std::vector<double> error = pointwise_error(p, y);
	return *max_element(error.begin(), error.end());
}

double f1_d(double x)
{
	return pow(x - 2, 9);
}

float f1_f(float x)
{
	return pow(x - 2, 9);
}

double f2_d(double x)
{
	double running_product = 1;
	for (size_t i = 1; i < d + 1; i++)
	{
		running_product = running_product * (x - i);
	}
	return running_product;
}

float f2_f(float x)
{
	float running_product = 1;
	for (size_t i = 1; i < d + 1; i++)
	{
		running_product = running_product * (x - i);
	}
	return running_product;
}

double f3_d(double x)
{
	if (x == x_igd.at(global_n))
	{
		return 1;
	}
	else
		return 0;
}

float f3_f(float x)
{
	if (x == x_igd.at(global_n))
	{
		return 1;
	}
	else
		return 0;
}

float d3_f(float x)
{
	if (x == x_igf.at(global_n))
	{
		return 1;
	}
	else
		return 0;
}

double f4_d(double x)
{
	return (1 / (1 + 25 * pow(x, 2)));
}

float f4_f(float x)
{
	return (1 / (1 + 25 * pow(x, 2)));
}

double testf(double x)
{
	return pow(x, 3) - 2 * pow(x, 2) + 7 * x - 5;
}
float testf(float x)
{
	return pow(x, 3) - 2 * pow(x, 2) + 7 * x - 5;
}

void barycentric_routine1(size_t n, Mesh type, double (*f)(double), double left_endpoint, double right_endpoint)
{
	std::vector<double> beta{ base_calculator(global_n, type, left_endpoint) };
	std::vector<double> x{ x_calculator(type, n, left_endpoint, right_endpoint) };
	std::vector<double> y{ y_calculator(x, f4_d) };

	std::cout << "The vector X is: (";
	for (size_t i = 0; i < global_n; i++)
	{
		if (i != global_n - 1)
		{
			std::cout << x.at(i) << ", ";
		}
		else
		{
			std::cout << x.at(i) << ")";
		}

	}
	std::cout << std::endl
		<< "The corrosponding vector f[x] is: (";
	for (size_t i = 0; i < global_n; i++)
	{
		if (i != global_n - 1)
		{
			std::cout << y.at(i) << ", ";
		}
		else
		{
			std::cout << y.at(i) << ")";
		}
	}
	std::cout << std::endl
		<< "The corrosponding vector of Barycentric weights are: (";
	for (size_t i = 0; i < global_n; i++)
	{
		if (i != global_n - 1)
		{
			std::cout << beta.at(i) << ", ";
		}
		else
		{
			std::cout << beta.at(i) << ")";
		}
	}
}

void barycentric_routine1(size_t n, Mesh type, float (*f)(float), float left_endpoint, float right_endpoint)
{
	std::vector<float> beta{ base_calculator(global_n, type, left_endpoint) };
	std::vector<float> x{ x_calculator(type, n, left_endpoint, right_endpoint) };
	std::vector<float> y{ y_calculator(x, f4_f) };

	std::cout << "The vector X is: (";
	for (size_t i = 0; i < global_n; i++)
	{
		if (i != global_n - 1)
		{
			std::cout << x.at(i) << ", ";
		}
		else
		{
			std::cout << x.at(i) << ")";
		}

	}
	std::cout << std::endl
		<< "The corrosponding vector f[x] is: (";
	for (size_t i = 0; i < global_n; i++)
	{
		if (i != global_n - 1)
		{
			std::cout << y.at(i) << ", ";
		}
		else
		{
			std::cout << y.at(i) << ")";
		}
	}
	std::cout << std::endl
		<< "The corrosponding vector of Barycentric weights are: (";
	for (size_t i = 0; i < global_n; i++)
	{
		if (i != global_n - 1)
		{
			std::cout << beta.at(i) << ", ";
		}
		else
		{
			std::cout << beta.at(i) << ")";
		}
	}
}

int factorial(unsigned n)
{
	if (n > 1)
	{
		return n * factorial(n - 1);
	}
	else
	{
		return 1;
	}
}

void display_p(size_t n, Mesh type, double left_endpoint, double right_endpoint, double (*f)(double))
{
	double h = (right_endpoint - left_endpoint) / n;
	std::vector<double> numerator;
	std::vector<double> denominator;
	std::vector<double> x{ x_calculator(type, n, left_endpoint, right_endpoint) };
	std::vector<double> y{ y_calculator(x, f) };
	std::vector<double> beta{ base_calculator(n, type, left_endpoint) };
	std::vector<double> gamma{ base_calculator(n, type, left_endpoint) };
	if (type == Mesh::uniform)
	{
		for (size_t i = 0; i < n; i++)
		{
			gamma.at(i) = ((gamma.at(i) * (pow(-1, n))) / (pow(h, n) * factorial(n)));
		}
	}

	std::cout << "p(x) is equal to: " << std::endl << "[";
	for (size_t i = 0; i < n; i++)
	{
		std::cout << y.at(i) * gamma.at(i) << " / (x - " << x.at(i) << ")";
		if (i != n - 1)
		{
			std::cout << " + ";
		}
	}
	std::cout << "]   /   [";
	for (size_t i = 0; i < n; i++)
	{
		std::cout << gamma.at(i) << " / (x - " << x.at(i) << ")";
		if (i != n - 1)
		{
			std::cout << " + ";
		}
	}
}

void display_p(size_t n, Mesh type, float left_endpoint, float right_endpoint, float (*f)(float))
{
	float h = (right_endpoint - left_endpoint) / n;
	std::vector<float> numerator;
	std::vector<float> denominator;
	std::vector<float> x{ x_calculator(type, n, left_endpoint, right_endpoint) };
	std::vector<float> y{ y_calculator(x, f) };
	std::vector<float> beta{ base_calculator(n, type, left_endpoint) };
	std::vector<float> gamma{ base_calculator(n, type, left_endpoint) };
	
	if (type == Mesh::uniform)
	{
		for (size_t i = 0; i < n; i++)
		{
			gamma.at(i) = static_cast<float>(((gamma.at(i) * (pow(-1, n))) / (pow(h, n) * factorial(n))));
		}
	}

	std::cout << "p(x) is equal to: " << std::endl << "[";
	for (size_t i = 0; i < n; i++)
	{
		std::cout << y.at(i) * gamma.at(i) << " / (x - " << x.at(i) << ")";
		if (i != n - 1)
		{
			std::cout << " + ";
		}
	}
	std::cout << "]   /   [";
	for (size_t i = 0; i < n; i++)
	{
		std::cout << gamma.at(i) << " / (x - " << x.at(i) << ")";
		if (i != n - 1)
		{
			std::cout << " + ";
		}
	}
}

std::vector<float> evaluate_p(size_t n, Mesh type, float left_endpoint, float right_endpoint, float (*f)(float))
{
	float h = (right_endpoint - left_endpoint) / n;
	std::vector<float> numerator(n);
	std::vector<float> denominator(n);
	std::vector<float> x{ x_calculator(type, n, left_endpoint, right_endpoint) };
	std::vector<float> y{ y_calculator(x, f) };
	std::vector<float> beta{ base_calculator(n, type, left_endpoint) };
	std::vector<float> gamma{ base_calculator(n, type, left_endpoint) };
	std::vector<float> p_hat(n);
	if (type == Mesh::uniform)
	{
		for (size_t i = 0; i < n; i++)
		{
			gamma.at(i) = static_cast<float>(((gamma.at(i) * (pow(-1, n))) / (pow(h, n) * factorial(n))));
		}
	}
	const double EPSILON = 0.00000001;
	for (size_t i = 0; i < n; i++)
	{
		for (size_t j = 0; j < n; j++)
		{
			if (abs(x.at(i) - x.at(j)) > EPSILON)
			{
				numerator.at(i) += y.at(i) * gamma.at(i) / (x.at(i) - x.at(j));
				denominator.at(i) += gamma.at(i) / (x.at(i) - x.at(j));
			}
			else
			{
				numerator.at(i) = y.at(i);
				denominator.at(i) = 1;
			}
		}
		p_hat.at(i) = numerator.at(i) / denominator.at(i);
	}
	return p_hat;
}

void horner_display(size_t n, std::vector<double> div_diff_table, std::vector<double> x)
{
	std::cout << "The polynomial written using Horner's rule is: " << std::endl;
	std::cout << "p(x) = " << div_diff_table.at(0) << " + ";
	for (size_t i = 1; i < n; i++)
	{
		for (size_t j = 0; j < i; j++)
		{
			std::cout << "(x - " << x.at(j) << ")";
		}
		std::cout << div_diff_table.at(n * i) << " + ";
	}
}

void horner_display(size_t n, std::vector<float> div_diff_table, std::vector<float> x)
{
	std::cout << "The polynomial written using Horner's rule is: " << std::endl;
	std::cout << "p(x) = " << div_diff_table.at(0) << " + ";
	for (size_t i = 1; i < n; i++)
	{
		for (size_t j = 0; j < i; j++)
		{
			std::cout << "(x - " << x.at(j) << ")";
		}
		std::cout << div_diff_table.at(n * i) << " + ";
	}
}

std::vector<float> horner_evaluation(std::vector<float> x, size_t n, std::vector<float> div_diff_table)
{
	std::vector<float> p_hat;
	p_hat.resize(x.size());
	float p_i = div_diff_table.at(0);

	for (size_t i = 0; i < x.size(); i++)
	{
		p_i = div_diff_table.at(0);
		for (size_t j = 1; j < n; j++)
		{
			float running_product = 1;
			for (size_t k = 0; k < j; k++)
			{
				running_product = running_product * (x.at(i) - x.at(k));
			}
			running_product = running_product * div_diff_table.at(n * j); 
			p_i += running_product;
		}
		p_hat.at(i) = p_i;
	}
	return p_hat;
}

void divided_differences(size_t n, std::vector<double> x, std::vector<double> y, std::vector<double>& div_diff_table, Order ordering)
{
	if (ordering == Order::decreasing)
	{
		x_ordering(x, Order::decreasing);
	}
	else if (ordering == Order::increasing)
	{
		x_ordering(x, Order::increasing);
	}
	else
	{
		x_ordering(x, Order::leja);
	}
	div_diff_table.resize(n * n);
	for (size_t i = 0; i < n; i++)
	{
		div_diff_table.at(i) = y.at(i);
	}
	for (size_t i = 1; i < n; i++)
	{
		for (size_t k = i * n; k < i * n + (n - i); k++)
		{
			div_diff_table.at(k) = (div_diff_table.at(k - (n - 1)) - div_diff_table.at(k - n))
				/ (x.at(k - (i * n) + i) - x.at(k - (n * i)));
		}
	}
	std::cout << "The divided differences are: " << std::endl;
	for (size_t i = 0; i < div_diff_table.size(); i++)
	{
		std::cout << div_diff_table.at(i) << " ";
		if (i % n == 3)
		{
			std::cout << std::endl;
		}
	}
}

void divided_differences(size_t n, std::vector<float> x, std::vector<float> y, std::vector<float>& div_diff_table, Order ordering)
{
	if (ordering == Order::decreasing)
	{
		x_ordering(x, Order::decreasing);
	}
	else if (ordering == Order::increasing)
	{
		x_ordering(x, Order::increasing);
	}
	else
	{
		x_ordering(x, Order::leja);
	}
	div_diff_table.resize(n * n);
	for (size_t i = 0; i < n; i++)
	{
		div_diff_table.at(i) = y.at(i);
	}
	for (size_t i = 1; i < n; i++)
	{
		for (size_t k = i * n; k < i * n + (n - i); k++)
		{
			div_diff_table.at(k) = (div_diff_table.at(k - (n - 1)) - div_diff_table.at(k - n))
				/ (x.at(k - (i * n) + i) - x.at(k - (n * i)));
		}
	}
	for (size_t i = 0; i < div_diff_table.size(); i++)
	{
		std::cout << div_diff_table.at(i) << " ";
		if (i % n == 3)
		{
			std::cout << std::endl;
		}
	}
}

